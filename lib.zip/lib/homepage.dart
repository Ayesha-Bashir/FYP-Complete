
import 'package:flutter/material.dart';
import 'package:smartp/data/local/db_helper.dart';

class HomePage extends StatefulWidget {
  ///const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  List<Map<String, dynamic>> allNotes = [];
  DBHelper? dbref;
  TextEditingController titleController = TextEditingController();
  TextEditingController desController = TextEditingController();
  String errormessage = " ";



  @override
  void initState() {
    super.initState();
    dbref = DBHelper.instance;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notes"),
      ),
      body: allNotes.isNotEmpty
          ? ListView.builder(
        itemCount: allNotes.length,
        itemBuilder: (_, index) {
          return ListTile(
            leading: Text('${index+1}'),
            title: Text(allNotes[index][DBHelper.COLUMN_TITLE]),
            subtitle: Text(allNotes[index][DBHelper.COLUMN_DESCRIPTION]),
            trailing:  SizedBox(
              width: 50,
              child: Row(
              children: [
                InkWell(
                    onTap: (){
                     showModalBottomSheet(
                       context: context, builder: (context){
                         titleController.text  = allNotes[index][DBHelper.COLUMN_TITLE];
                         desController.text = allNotes[index][DBHelper.COLUMN_DESCRIPTION];
                         return getBottomSheetWidget(isUpdate : true, sno: allNotes[index][DBHelper.COLUMN_SERIAL]);
                     });

    },
                    child: Icon(Icons.edit, color: Colors.orange)
                ),
                InkWell(
                    onTap: ()async{

                    },
                    child: Icon(Icons.delete, color: Colors.red,)

                ),
              ],
            ),
            ),
          );
        },
      )
          : Center(
        child: Text('No Notes Yet!!'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {

          showModalBottomSheet(context: context, builder: (context){
            titleController.clear();
            desController.clear();
                  return getBottomSheetWidget();
          });

        },
        child: Icon(Icons.add),
      ),
    );
  }
  Widget getBottomSheetWidget({bool isUpdate=false, int sno = 0}){
    return Container(
      padding: EdgeInsets.all(11),
      width: double.infinity,
      child: Column(
        children: [
          Text(isUpdate ? 'Update Note' : 'Add Note', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
          SizedBox(
            height: 21,
          ),
          TextField(
            controller: titleController,
            decoration: InputDecoration(
                hintText: 'Enter Title here',
                label: Text('Title*'),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(11),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(11),
                )
            ),
          ),

          SizedBox(height: 15),
          TextField(
            controller: desController,
            maxLines: 4,
            decoration: InputDecoration(
                hintText: 'Enter Description here',
                label: Text('Description*'),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(11),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(11),
                )
            ),
          ),

          SizedBox(height: 15),

          Row(
            children: [
              Expanded(child: OutlinedButton(
                  onPressed: ()async{
                var title = titleController.text;
                var desc = desController.text;
                if(title.isNotEmpty && desc.isNotEmpty){

                }

              },
                  child: Text(isUpdate ? 'Update Note' :'Add Note')),
              ),
              SizedBox(height: 10),
              Expanded(child: OutlinedButton(onPressed: (){
                Navigator.pop(context);
              }, child: Text('Cancle'))),
              Text(errormessage),
            ],
          )

        ],
      ),
    );
  }
}
