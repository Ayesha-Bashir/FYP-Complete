import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';

class PlantInfoCard extends StatefulWidget {
  final Map<String, dynamic> plantData;

  const PlantInfoCard({Key? key, required this.plantData}) : super(key: key);

  @override
  _PlantInfoCardState createState() => _PlantInfoCardState();
}

class _PlantInfoCardState extends State<PlantInfoCard> {
  Map<String, dynamic>? _plantDetails;
  String? _error;
  bool _isLoading = false;
  bool _isExpanded = false;

  @override
  void initState() {
    super.initState();
    // Automatically fetch details when widget is created
    _fetchPlantDetails();
  }

  @override
  Widget build(BuildContext context) {
    final results = widget.plantData['results'] as List;
    if (results.isEmpty) {
      return _buildNoMatchCard();
    }

    final bestMatch = results.first;
    final species = bestMatch['species'];
    final score = (bestMatch['score'] * 100).toStringAsFixed(1);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: Colors.green.shade200, width: 1),
      ),
      margin: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Image Section
          if (bestMatch['images']?.isNotEmpty ?? false)
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: CachedNetworkImage(
                imageUrl: bestMatch['images'][0]['url'],
                height: 200,
                fit: BoxFit.cover,
                placeholder: (context, url) => Container(
                  height: 200,
                  color: Colors.grey[200],
                  child: const Center(
                    child: CircularProgressIndicator(),
                  ),
                ),
                errorWidget: (context, url, error) => Container(
                  height: 200,
                  color: Colors.grey[200],
                  child: const Icon(Icons.error),
                ),
              ),
            ),

          // Content Section
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 16),
                _buildSectionHeader('Plant Identification', context),
                const Divider(height: 24),
                _buildInfoRow('Scientific Name', species['scientificName']),
                _buildInfoRow('Common Names',
                    (species['commonNames'] as List?)?.join(', ') ?? 'Not available'),
                _buildInfoRow('Family', species['family']['scientificName']),

                if (species['description'] != null) ...[
                  const SizedBox(height: 16),
                  _buildSectionHeader('Species Description', context),
                  const SizedBox(height: 8),
                  _buildExpandableText(species['description']),
                ],

                if (_error != null) ...[
                  const SizedBox(height: 16),
                  _buildErrorWidget(),
                ],

                if (_plantDetails != null && _plantDetails!['extract'] != null) ...[
                  const SizedBox(height: 16),
                  _buildWikipediaSection(),
                ],

                const SizedBox(height: 16),
                _buildActionButtons(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConfidenceIndicator(double confidence) {
    Color indicatorColor = confidence > 80
        ? Colors.green
        : confidence > 60
        ? Colors.orange
        : Colors.red;

    return Row(
      children: [
        CircularProgressIndicator(
          value: confidence / 100,
          backgroundColor: Colors.grey[200],
          valueColor: AlwaysStoppedAnimation<Color>(indicatorColor),
        ),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Confidence Level',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
            Text(
              '${confidence.toStringAsFixed(1)}%',
              style: TextStyle(
                color: indicatorColor,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildNoMatchCard() {
    return Card(
      margin: const EdgeInsets.all(20),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          children: [
            Icon(Icons.search_off, size: 48, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(
              'No Plant Matches Found',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Try taking another photo with better lighting and focus',
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 24,
          decoration: BoxDecoration(
            color: Colors.green[700],
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.green[700],
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey[600],
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.black87,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExpandableText(String text) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AnimatedCrossFade(
          firstChild: Text(
            text,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.black87),
          ),
          secondChild: Text(
            text,
            style: const TextStyle(color: Colors.black87),
          ),
          crossFadeState: _isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
          duration: const Duration(milliseconds: 300),
        ),
        TextButton(
          onPressed: () => setState(() => _isExpanded = !_isExpanded),
          child: Text(
            _isExpanded ? 'Show Less' : 'Read More',
            style: TextStyle(color: Colors.green[700]),
          ),
        ),
      ],
    );
  }

  Widget _buildErrorWidget() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red[200]!),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: Colors.red[700]),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _error!,
              style: TextStyle(color: Colors.red[700]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWikipediaSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green[100]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Image.network(
                'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Wikipedia-logo-v2.svg/103px-Wikipedia-logo-v2.svg.png',
                height: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Wikipedia Description',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            _plantDetails?['extract'] ?? 'No description available.',
            style: const TextStyle(
              color: Colors.black87,
              height: 1.5,
            ),
            textAlign: TextAlign.justify,
          ),
          if (_plantDetails?['content_urls']?['desktop']?['page'] != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: TextButton.icon(
                icon: const Icon(Icons.open_in_new),
                label: const Text('Read More on Wikipedia'),
                onPressed: () => _launchWikipediaURL()
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _launchWikipediaURL() async {
    final wikiURL = _plantDetails?['content_urls']?['desktop']?['page'];
    if (wikiURL != null) {
      final Uri url = Uri.parse(wikiURL);
      try {
        if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
          throw Exception('Could not launch $url');
        }
      } catch (e) {
        setState(() {
          _error = 'Could not open Wikipedia page: ${e.toString()}';
        });
      }
    }
  }


  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        ElevatedButton.icon(
          onPressed: _isLoading ? null : _fetchPlantDetails,
          icon: _isLoading
              ? const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(strokeWidth: 2),
          )
              : const Icon(Icons.refresh),
          label: Text(_isLoading ? 'Loading...' : 'Refresh Details'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green[700],
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _fetchPlantDetails() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final species = widget.plantData['results'][0]['species'];
      final scientificName = species['scientificName'];

      // First try with the full scientific name
      var wikiData = await _tryFetchWikiData(scientificName);

      // If no results, try with just the genus name
      if (wikiData == null && scientificName.contains(' ')) {
        final genus = scientificName.split(' ')[0];
        wikiData = await _tryFetchWikiData(genus);
      }

      if (wikiData != null) {
        setState(() {
          _isLoading = false;
          _plantDetails = wikiData;
        });
      } else {
        setState(() {
          _isLoading = false;
          _error = 'No Wikipedia information found for this plant.';
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _error = 'Error fetching plant details: ${e.toString()}';
      });
    }
  }

  Future<Map<String, dynamic>?> _tryFetchWikiData(String searchTerm) async {
    try {
      final url = Uri.parse(
          'https://en.wikipedia.org/api/rest_v1/page/summary/${Uri.encodeComponent(searchTerm)}'
      );
      final response = await http.get(url);

      if (response.statusCode == 200) {
        return json.decode(response.body);
      }
    } catch (e) {
      print('Error fetching wiki data for $searchTerm: $e');
    }
    return null;
  }
}