import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DBHelper {
  DBHelper._();

  static final DBHelper instance = DBHelper._();

  // Order Table and Column Names
  static const String TABLE_ORDER = "Orders";
  static const String COLUMN_ORDER_ID = "order_id";
  static const String COLUMN_CUSTOMER_NAME = "customer_name";
  static const String COLUMN_PHONE = "customer_phone";
  static const String COLUMN_ADDRESS = "customer_address";
  static const String COLUMN_EMAIL = "customer_email";  // Make sure this matches exactly
  static const String COLUMN_TOTAL_AMOUNT = "total_amount";
  static const String COLUMN_STATUS = "status";
  static const String COLUMN_PAY_ON_DELIVERY = "pay_on_delivery";

  // Notes Table
  static const String TABLE_NOTE = "Notes";
  static const String COLUMN_SERIAL = "s_no";
  static const String COLUMN_TITLE = "title";
  static const String COLUMN_DESCRIPTION = "description";

  // Users Table
  static const String TABLE_USER = "Users";
  static const String COLUMN_UID = "u_id";
  static const String COLUMN_Name = "name";
  static const String COLUMN_Email = "email";

  // Products Table
  static const String TABLE_PRODUCT = "Products";
  static const String COLUMN_PID = "p_id";
  static const String COLUMN_PNAME = "name";
  static const String COLUMN_PIMAGE = "imageUrl";
  static const String COLUMN_PPRICE = "price";
  static const String COLUMN_PDESCRIPTION = "description";
  static const String COLUMN_PQUANTITY = "quantity";

  Database? _database;

  Future<Database> getDB() async {
    if (_database != null) return _database!;

    // If database doesn't exist, delete it first to ensure clean slate
    Directory appDir = await getApplicationDocumentsDirectory();
    String dbPath = join(appDir.path, "app.db");

    // Delete existing database to force recreation
    /*if (await File(dbPath).exists()) {
      await deleteDatabase(dbPath);
    }*/

    _database = await openDB();
    return _database!;
  }

  Future<Database> openDB() async {
    Directory appDir = await getApplicationDocumentsDirectory();
    String dbPath = join(appDir.path, "app.db");

    return await openDatabase(
      dbPath,
      version: 1,  // Reset to version 1 since we're recreating
      onCreate: (db, version) async {
        // Create Orders Table with correct column names
        await db.execute('''
          CREATE TABLE $TABLE_ORDER (
            $COLUMN_ORDER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_CUSTOMER_NAME TEXT,
            $COLUMN_PHONE TEXT,
            $COLUMN_ADDRESS TEXT,
            $COLUMN_EMAIL TEXT,
            $COLUMN_TOTAL_AMOUNT REAL,
            $COLUMN_STATUS TEXT,
            $COLUMN_PAY_ON_DELIVERY INTEGER
          )
        ''');

        // Create Notes Table
        await db.execute('''
          CREATE TABLE $TABLE_NOTE (
            $COLUMN_SERIAL INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_TITLE TEXT,
            $COLUMN_DESCRIPTION TEXT
          )
        ''');

        // Create Users Table
        await db.execute('''
          CREATE TABLE $TABLE_USER (
            $COLUMN_UID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_Name TEXT,
            $COLUMN_Email TEXT
          )
        ''');

        // Create Products Table
        await db.execute('''
          CREATE TABLE $TABLE_PRODUCT (
            $COLUMN_PID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_PNAME TEXT,
            $COLUMN_PIMAGE TEXT,
            $COLUMN_PPRICE REAL,
            $COLUMN_PDESCRIPTION TEXT,
            $COLUMN_PQUANTITY INTEGER
          )
        ''');

        // Create Order Items Table
        await db.execute('''
          CREATE TABLE order_items (
            order_item_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            product_id INTEGER,
            quantity INTEGER,
            price REAL,
            new_quantity INTEGER,
            FOREIGN KEY (order_id) REFERENCES $TABLE_ORDER ($COLUMN_ORDER_ID),
            FOREIGN KEY (product_id) REFERENCES $TABLE_PRODUCT ($COLUMN_PID)
          )
        ''');
      },
    );
  }

  // Add Order method with corrected column names
  Future<bool> addOrder({
    required String customerName,
    required String customerPhone,
    required String customerAddress,
    required double totalAmount,
    required String status,
    required bool payOnDelivery,
    required String customerEmail,
  }) async {
    var db = await getDB();

    try {
      int rowsAffected = await db.insert(TABLE_ORDER, {
        COLUMN_CUSTOMER_NAME: customerName,
        COLUMN_PHONE: customerPhone,
        COLUMN_ADDRESS: customerAddress,
        COLUMN_EMAIL: customerEmail,
        COLUMN_TOTAL_AMOUNT: totalAmount,
        COLUMN_STATUS: status,
        COLUMN_PAY_ON_DELIVERY: payOnDelivery ? 1 : 0,
      });

      return rowsAffected > 0;
    } catch (e) {
      print('Error adding order: $e');
      return false;
    }
  }

  // The createOrder method with corrected column names
  Future<int> createOrder({
    required double totalAmount,
    required String status,
    required List<Map<String, dynamic>> orderItems,
    required String customerName,
    required String customerPhone,
    required String customerAddress,
    required String customerEmail,
    required bool payOnDelivery,
  }) async {
    var db = await getDB();

    return await db.transaction((txn) async {
      final orderId = await txn.insert(TABLE_ORDER, {
        COLUMN_CUSTOMER_NAME: customerName,
        COLUMN_PHONE: customerPhone,
        COLUMN_ADDRESS: customerAddress,
        COLUMN_EMAIL: customerEmail,
        COLUMN_TOTAL_AMOUNT: totalAmount,
        COLUMN_STATUS: status,
        COLUMN_PAY_ON_DELIVERY: payOnDelivery ? 1 : 0,
      });

      for (var item in orderItems) {
        await txn.insert('order_items', {
          'order_id': orderId,
          'product_id': item['product_id'],
          'quantity': item['quantity'],
          'price': item['price'],
          'new_quantity': item['new_quantity'],
        });

        await txn.update(
          TABLE_PRODUCT,
          {'quantity': item['new_quantity']},
          where: '$COLUMN_PID = ?',
          whereArgs: [item['product_id']],
        );
      }

      return orderId;
    });
  }

  // Get All Orders
  Future<List<Map<String, dynamic>>> getAllOrders() async {
    var db = await getDB();
    return await db.query(TABLE_ORDER);
  }

  // Delete Order
  Future<int> deleteOrder(int orderId) async {
    var db = await getDB();
    await db.delete('order_items', where: 'order_id = ?', whereArgs: [orderId]);
    return await db.delete(TABLE_ORDER, where: '$COLUMN_ORDER_ID = ?', whereArgs: [orderId]);
  }

  Future<int> updateOrder({
    required int orderId,
    required String customerName,
    required String customerPhone,
    required String customerAddress,
    required String customerEmail,
    required double totalAmount,
    required String status,
    required bool payOnDelivery,
  }) async {
    var db = await getDB();

    return await db.update(
      TABLE_ORDER,
      {
        COLUMN_CUSTOMER_NAME: customerName,
        COLUMN_PHONE: customerPhone,
        COLUMN_ADDRESS: customerAddress,
        COLUMN_EMAIL: customerEmail,
        COLUMN_TOTAL_AMOUNT: totalAmount,
        COLUMN_STATUS: status,
        COLUMN_PAY_ON_DELIVERY: payOnDelivery ? 1 : 0,
      },
      where: '$COLUMN_ORDER_ID = ?',
      whereArgs: [orderId],
    );
  }

  Future<List<Map<String, dynamic>>> getOrdersByEmail(String email) async {
    var db = await getDB();
    return await db.query(
      TABLE_ORDER,
      where: '$COLUMN_EMAIL = ?',
      whereArgs: [email],
    );
  }

  Future<bool> addProduct({
    required String name,
    required String imageUrl,
    required double price,
    required String description,
    required int quantity,
  }) async {
    var db = await getDB();
    int rowsAffected = await db.insert(TABLE_PRODUCT, {
      COLUMN_PNAME: name,
      COLUMN_PIMAGE: imageUrl,
      COLUMN_PPRICE: price,
      COLUMN_PDESCRIPTION: description,
      COLUMN_PQUANTITY: quantity,
    });
    return rowsAffected > 0;
  }

  // Get All Products
  Future<List<Map<String, dynamic>>> getAllProducts() async {
    var db = await getDB();
    List<Map<String, dynamic>> products = await db.query(TABLE_PRODUCT);
    return products;
  }

  // Update Note
  Future<bool> updateNote({
    required String title,
    required String description,
    required int id,
  }) async {
    var db = await getDB();
    int rowsAffected = await db.update(TABLE_NOTE, {
      COLUMN_TITLE: title,
      COLUMN_DESCRIPTION: description,
    }, where: "$COLUMN_SERIAL = ?", whereArgs: [id]);
    return rowsAffected > 0;
  }

  // Delete Note
  Future<int> deleteNote({
    required int id,
  }) async {
    var db = await getDB();
    return await db.delete(TABLE_NOTE, where: "$COLUMN_SERIAL = ?", whereArgs: [id]);
  }

  // Update User
  Future<int> updateUser({
    required String name,
    required String newEmail,
    required String currentEmail,  // change this to accept current email
  }) async {
    var db = await getDB();
    return await db.update(TABLE_USER, {
      COLUMN_Name: name,
      COLUMN_Email: newEmail,
    }, where: "$COLUMN_Email = ?", whereArgs: [currentEmail]);
  }


  // Delete User
  Future<int> deleteUser({
    required String email,  // change this to accept email instead of id
  }) async {
    var db = await getDB();
    return await db.delete(TABLE_USER, where: "$COLUMN_Email = ?", whereArgs: [email]);
  }


  // Update Product
  Future<int> updateProduct({
    required String name,
    required String imageUrl,
    required double price,
    required String description,
    required int quantity,
    required int id,
  }) async {
    var db = await getDB();
    return await db.update(TABLE_PRODUCT, {
      COLUMN_PNAME: name,
      COLUMN_PIMAGE: imageUrl,
      COLUMN_PPRICE: price,
      COLUMN_PDESCRIPTION: description,
      COLUMN_PQUANTITY: quantity,
    }, where: "$COLUMN_PID = ?", whereArgs: [id]);
  }

  // Delete Product
  Future<int> deleteProduct({
    required int id,
  }) async {
    var db = await getDB();
    return await db.delete(TABLE_PRODUCT, where: "$COLUMN_PID = ?", whereArgs: [id]);
  }

  // Get All Users
  Future<List<Map<String, dynamic>>> getAllUsers() async {
    var db = await getDB();
    List<Map<String, dynamic>> users = await db.query(TABLE_USER);
    return users;
  }

  // Add User
  Future<bool> addUser({
    required String name,
    required String email,
  }) async {
    var db = await getDB();
    int rowsAffected = await db.insert(TABLE_USER, {
      COLUMN_Name: name,
      COLUMN_Email: email,
    });
    return rowsAffected > 0;
  }

  // Get order items with product details
  Future<List<Map<String, dynamic>>> getOrderItems(int orderId) async {
    var db = await getDB();
    return await db.rawQuery('''
    SELECT oi.quantity, p.name AS product_name
    FROM order_items oi
    JOIN Products p ON oi.product_id = p.p_id
    WHERE oi.order_id = ?
  ''', [orderId]);
  }


}
