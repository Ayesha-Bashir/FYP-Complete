import 'package:flutter/material.dart';
import 'dart:io';
import 'package:smartp/data/local/db_helper.dart';

class PlantCareProduct {
  final int id;
  final String name;
  final String imageUrl;
  final double price;
  final String description;
  int totalQuantity;

  PlantCareProduct({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.description,
    required this.totalQuantity,
  });
}

class CartItem {
  final PlantCareProduct product;
  int quantity;

  CartItem({required this.product, this.quantity = 1});
}

class ShopScreen extends StatefulWidget {
  @override
  _ShopScreenState createState() => _ShopScreenState();
}

class _ShopScreenState extends State<ShopScreen> {
  List<PlantCareProduct> products = [];
  List<CartItem> cartItems = [];
  final DBHelper dbHelper = DBHelper.instance;

  @override
  void initState() {
    super.initState();
    fetchProductsFromDatabase();
  }

  Future<void> fetchProductsFromDatabase() async {
    List<Map<String, dynamic>> productData = await dbHelper.getAllProducts();
    setState(() {
      products = productData.map((product) {
        return PlantCareProduct(
          id: product['p_id'],
          name: product['name'],
          imageUrl: product['imageUrl'],
          price: product['price'],
          description: product['description'],
          totalQuantity: product['quantity'],
        );
      }).toList();
    });
  }

  void addToCart(PlantCareProduct product) {
    if (product.totalQuantity > 0) {
      setState(() {
        final existingIndex = cartItems.indexWhere((item) => item.product.id == product.id);
        if (existingIndex >= 0) {
          cartItems[existingIndex].quantity += 1;
        } else {
          cartItems.add(CartItem(product: product));
        }
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No more ${product.name} available.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Plant Care Products', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CartScreen(cartItems: cartItems, onOrderPlaced: fetchProductsFromDatabase),
                ),
              );
            },
          ),
        ],
      ),
      body: products.isEmpty
          ? Center(child: CircularProgressIndicator())
          : GridView.builder(
        padding: EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductCard(product: products[index], onAddToCart: addToCart);
        },
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final PlantCareProduct product;
  final Function(PlantCareProduct) onAddToCart;

  const ProductCard({Key? key, required this.product, required this.onAddToCart}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProductDetailScreen(product: product, onAddToCart: onAddToCart),
          ),
        );
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                  image: DecorationImage(
                    image: FileImage(File(product.imageUrl)),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text('Rs ${product.price.toStringAsFixed(2)}'),
                  SizedBox(height: 4),
                  Text('Available: ${product.totalQuantity}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProductDetailScreen extends StatelessWidget {
  final PlantCareProduct product;
  final Function(PlantCareProduct) onAddToCart;

  const ProductDetailScreen({Key? key, required this.product, required this.onAddToCart}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product.name),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.file(File(product.imageUrl), width: double.infinity, height: 300, fit: BoxFit.cover),
            Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, style: Theme.of(context).textTheme.headlineSmall),
                  SizedBox(height: 8),
                  Text('Rs ${product.price.toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Theme.of(context).primaryColor)),
                  SizedBox(height: 8),
                  Text('Available: ${product.totalQuantity}', style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 16),
                  Text('Description', style: Theme.of(context).textTheme.titleMedium),
                  SizedBox(height: 8),
                  Text(product.description),
                  SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: product.totalQuantity > 0
                        ? () {
                      onAddToCart(product);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added to cart')));
                    }
                        : null,
                    child: Text('Add to Cart'),
                    style: ElevatedButton.styleFrom(minimumSize: Size(double.infinity, 50)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CartScreen extends StatefulWidget {
  final List<CartItem> cartItems;
  final VoidCallback onOrderPlaced;

  const CartScreen({
    Key? key,
    required this.cartItems,
    required this.onOrderPlaced,
  }) : super(key: key);

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final DBHelper dbHelper = DBHelper.instance;
  String selectedStatus = 'Placed';
  bool isProcessing = false;

  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController emailController = TextEditingController(); // Added email controller
  bool payOnDelivery = false;

  final List<String> orderStatuses = ['Placed', 'Shipped', 'Delivered', 'Cancelled'];

  double get totalAmount {
    return widget.cartItems.fold(0, (sum, item) => sum + (item.product.price * item.quantity));
  }

  void _showOrderSuccessDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.check_circle, color: Colors.green, size: 80),
                SizedBox(height: 20),
                Text(
                  'Order Placed Successfully!',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 10),
                Text(
                  'Thank you for your purchase.',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop(); // Close dialog
                    Navigator.of(context).pop(); // Close cart screen
                  },
                  child: Text('Continue Shopping'),
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> placeOrder() async {
    if (widget.cartItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cart is empty')));
      return;
    }

    // Enhanced validation with email and comprehensive checks
    if (nameController.text.isEmpty ||
        phoneController.text.isEmpty ||
        addressController.text.isEmpty ||
        emailController.text.isEmpty ||
        !RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(emailController.text)) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please fill all fields correctly, including a valid email'),
            backgroundColor: Colors.red,
          )
      );
      return;
    }

    setState(() => isProcessing = true);

    try {
      final orderItems = widget.cartItems.map((item) => {
        'product_id': item.product.id,
        'quantity': item.quantity,
        'price': item.product.price,
        'new_quantity': item.product.totalQuantity - item.quantity,
      }).toList();

      final orderId = await dbHelper.createOrder(
        totalAmount: totalAmount,
        status: selectedStatus,
        orderItems: orderItems,
        customerName: nameController.text,
        customerPhone: phoneController.text,
        customerAddress: addressController.text,
        customerEmail: emailController.text, // Added email parameter
        payOnDelivery: payOnDelivery,
      );

      widget.cartItems.clear();
      widget.onOrderPlaced();

      // Replace SnackBar with custom dialog
      _showOrderSuccessDialog();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to place order: ${e.toString()}'),
            backgroundColor: Colors.red,
          )
      );
    } finally {
      setState(() => isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping Cart', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: widget.cartItems.length,
              itemBuilder: (context, index) {
                final item = widget.cartItems[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      children: [
                        Image.file(
                            File(item.product.imageUrl),
                            width: 80,
                            height: 80,
                            fit: BoxFit.cover
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                  item.product.name,
                                  style: TextStyle(fontWeight: FontWeight.bold)
                              ),
                              Text('Rs ${item.product.price.toStringAsFixed(2)}'),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(Icons.remove_circle, color: Colors.red),
                              onPressed: () {
                                setState(() {
                                  if (item.quantity > 1) {
                                    item.quantity--;
                                  } else {
                                    widget.cartItems.removeAt(index);
                                  }
                                });
                              },
                            ),
                            Text('${item.quantity}'),
                            IconButton(
                              icon: Icon(Icons.add_circle, color: Colors.green),
                              onPressed: () {
                                setState(() {
                                  if (item.quantity < item.product.totalQuantity) {
                                    item.quantity++;
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text('Maximum available quantity reached'),
                                          backgroundColor: Colors.orange,
                                        )
                                    );
                                  }
                                });
                              },
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16),
            child: Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(
                        labelText: 'Full Name',
                        prefixIcon: Icon(Icons.person),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: phoneController,
                      decoration: InputDecoration(
                        labelText: 'Phone Number',
                        prefixIcon: Icon(Icons.phone),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      keyboardType: TextInputType.phone,
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: emailController,
                      decoration: InputDecoration(
                        labelText: 'Email Address',
                        prefixIcon: Icon(Icons.email),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: addressController,
                      decoration: InputDecoration(
                        labelText: 'Delivery Address',
                        prefixIcon: Icon(Icons.location_on),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      maxLines: 2,
                    ),
                    SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Pay on Delivery', style: TextStyle(fontSize: 16)),
                        Switch(
                          value: payOnDelivery,
                          onChanged: (value) {
                            setState(() {
                              payOnDelivery = value;
                            });
                          },
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Total Amount: Rs ${totalAmount.toStringAsFixed(2)}',
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: isProcessing ? null : placeOrder,
                      icon: Icon(Icons.shopping_cart_checkout),
                      label: Text(
                        isProcessing ? 'Processing...' : 'Place Order',
                        style: TextStyle(fontSize: 16),
                      ),
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(double.infinity, 50),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}