import 'package:flutter/material.dart';
import 'package:smartp/Adminside/adminnavbar.dart';
import 'package:smartp/Adminside/adminside.dart';
import 'package:smartp/data/local/db_helper.dart';
///import 'package:smartp/screens/home.dart';
import 'package:smartp/screens/navbar.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isLogin = true;
  List<Map<String, dynamic>> allUsers = [];
  DBHelper? dbref;
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  String errorMessage = "";
  final _formKey = GlobalKey<FormState>();


  @override
  void initState() {
    super.initState();
    dbref = DBHelper.instance;
    getUsers();
  }

  void getUsers() async {
    allUsers = await dbref!.getAllUsers();
    setState(() {});
  }

  Future<void> signUpUser() async {
    var name = nameController.text;
    var email = emailController.text;
    var passw = passwordController.text;

    if (_formKey.currentState!.validate()) {
      bool userExists = allUsers.any((user) => user[DBHelper.COLUMN_Email] == email);
      if (!userExists) {
        // Add user to the database
        bool check = await dbref!.addUser(name: name, email: email); // Include password here
        if (check) {
          setState(() {
            errorMessage = "User registered successfully! Please log in.";
            getUsers(); // Fetch updated user list
          });
          // Optionally clear fields or reset the form
          // Clear fields if needed
          emailController.clear();
          passwordController.clear();
          nameController.clear();
          // Optionally navigate to the login page if you have a separate one
        }
      } else {
        setState(() {
          errorMessage = "Email already in use!";
        });
      }
    }
  }

  Future<void> loginUser() async {
    var email = emailController.text;
    var passw = passwordController.text; // Ensure to capture the password input

    if (_formKey.currentState!.validate()) {
      // Check for admin credentials
      if (email == 'ayesha@gmail.com' && passw == '123456') {
        navigateToAdminPanel();
        return; // Early return after navigating to admin panel
      }

      // Check if user exists in the database
      bool userExists = allUsers.any((user) => user[DBHelper.COLUMN_Email] == email);
      if (userExists) {
        // Find the user's name and check password
        var user = allUsers.firstWhere((user) => user[DBHelper.COLUMN_Email] == email);
        if (user[DBHelper.COLUMN_Email] == email) { // Check if the password matches
          var userName = user[DBHelper.COLUMN_Name] as String;
          var userEmail = user[DBHelper.COLUMN_Email] as String;
          setState(() {
            errorMessage = "Login successful!";
          });
          navigateToHome(userName,userEmail ); // Pass the user's name to the Home screen
        } else {
          setState(() {
            errorMessage = "Invalid password!";
          });
        }
      } else {
        setState(() {
          errorMessage = "No account found with that email!";
        });
      }
    }
  }

  /// For user navigation
  void navigateToHome(String userName, String userEmail) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => NavBar(uuname: userName, uuemail :userEmail )), // Corrected parameter name
    );
  }

  /// For admin navigation
  void navigateToAdminPanel() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => ANavBar(uuname: '',)),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 100),
                  Image.asset('assets/logo2.png', height: 100),
                  const SizedBox(height: 50),
                  Text(
                    isLogin ? "Welcome Back!" : "Create Account",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade700,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  if (!isLogin) _buildNameField(),
                  const SizedBox(height: 16),
                  _buildEmailField(),
                  const SizedBox(height: 16),
                  _buildPasswordField(),
                  const SizedBox(height: 24),
                  _buildLoginButton(),
                  const SizedBox(height: 16),
                  _buildToggleAuthModeButton(),
                  if (errorMessage.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 16),
                      child: Text(
                        errorMessage,
                        style: const TextStyle(color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNameField() {
    return TextFormField(
      controller: nameController,
      decoration: _inputDecoration('Name', Icons.person_outline),
      validator: (value) {
        if (!isLogin && (value == null || value.isEmpty)) {
          return 'Please enter your name';
        }
        return null;
      },
    );
  }

  Widget _buildEmailField() {
    return TextFormField(
      controller: emailController,
      decoration: _inputDecoration('Email', Icons.email_outlined),
      keyboardType: TextInputType.emailAddress,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your email';
        }
        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
          return 'Please enter a valid email address';
        }
        return null;
      },
    );
  }

  Widget _buildPasswordField() {
    return TextFormField(
      controller: passwordController,
      decoration: _inputDecoration('Password', Icons.lock_outline),
      obscureText: true,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter your password';
        }
        if (value.length < 6) {
          return 'Password must be at least 6 characters long';
        }
        return null;
      },
    );
  }

  Widget _buildLoginButton() {
    return ElevatedButton(
      onPressed: isLogin ? loginUser : signUpUser,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.green.shade600,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Text(
        isLogin ? 'Login' : 'Sign Up',
        style: const TextStyle(fontSize: 18),
      ),
    );
  }

  Widget _buildToggleAuthModeButton() {
    return TextButton(
      onPressed: () {
        setState(() {
          isLogin = !isLogin;
          errorMessage = "";
        });
      },
      child: Text(
        isLogin ? "Don't have an account? Sign up" : "Already have an account? Login",
        style: TextStyle(color: Colors.green.shade700),
      ),
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: Colors.green),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: Colors.green.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: Colors.green.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: Colors.green.shade600),
      ),
    );
  }
}