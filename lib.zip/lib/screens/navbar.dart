import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smartp/screens/orderspage.dart';
import 'home.dart';
import 'profile.dart';
import 'package:smartp/screens/about_screen.dart';
import 'package:smartp/screens/help_screen.dart';

class NavBar extends StatefulWidget {
  final String uuname; // Field to store the username
  final String uuemail; // Field to store the username

  // Constructor to accept username
  const NavBar({Key? key, required this.uuname, required this.uuemail}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  late List<Widget?> screens;

  @override
  void initState() {
    super.initState();
    // Initialize the screens list using the passed username
    screens = [
      Home(username: widget.uuname),
      AboutScreen(),
      UserOrdersPage( userEmail: widget.uuemail,)
    ];
  }

  int selectedIndex = 0;
  Widget? selectedScreen;

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: screens[selectedIndex],
      bottomNavigationBar: Container(
        height: 80,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.15),
              blurRadius: 8.0,
              spreadRadius: 2.0,
              offset: Offset(0.0, -2.0),
            ),
          ],
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(40),
            topRight: Radius.circular(40),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            buildNavigationItem(width, Icons.info, 1, 'About'),

            // Centered Home icon with elevation effect
            GestureDetector(
              onTap: () {
                setState(() {
                  selectedIndex = 0;
                });
              },
              child: Container(
                width: 70,
                height: 70,
                margin: EdgeInsets.only(bottom: 15),  // Raise the Home icon
                decoration: BoxDecoration(
                  color: selectedIndex == 0 ? Colors.green : Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.green.withOpacity(0.4),
                      blurRadius: 8,
                      spreadRadius: 1,
                      offset: Offset(0, 3), // shadow offset for floating effect
                    ),
                  ],
                ),
                child: Icon(
                  Icons.home,
                  size: 40,
                  color: selectedIndex == 0 ? Colors.white : Colors.green,
                ),
              ),
            ),

            buildNavigationItem(width, CupertinoIcons.bag, 2, 'Orders'),
          ],
        ),
      ),
    );
  }

  Widget buildNavigationItem(double width, IconData icon, int index, String title) {
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
      },
      child: SizedBox(
        width: width / 5,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: index == selectedIndex ? Colors.green : Colors.grey,
              size: 26,
            ),
            SizedBox(height: 5),
            Text(
              title,
              style: TextStyle(
                fontSize: 13,
                color: index == selectedIndex ? Colors.green : Colors.grey,
                fontWeight: index == selectedIndex ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
