import 'dart:typed_data'; // Needed for image data

class Content {
  final String? text;
  final Uint8List? image; // Changed to Uint8List for image data

  // Constructor for text and image content
  Content({this.text, this.image});

  // Factory constructor for creating text content
  static Content createText(String text) {
    return Content(text: text);
  }

  // Factory constructor for creating image content
  static Content createImage(Uint8List imageBytes) {
    return Content(image: imageBytes);
  }

  // Method for creating multiple content types
  static List<Content> multi(List<Content> contents) {
    return contents; // Just return the list of contents
  }
}
