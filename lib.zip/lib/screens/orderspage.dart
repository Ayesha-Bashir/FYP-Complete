import 'package:flutter/material.dart';
import 'package:smartp/data/local/db_helper.dart';

class UserOrdersPage extends StatefulWidget {
  final String userEmail; // Pass the user's email as a parameter

  UserOrdersPage({required this.userEmail});

  @override
  _UserOrdersPageState createState() => _UserOrdersPageState();
}

class _UserOrdersPageState extends State<UserOrdersPage> {
  List<Map<String, dynamic>> userOrders = [];
  final DBHelper dbHelper = DBHelper.instance;

  @override
  void initState() {
    super.initState();
    fetchUserOrders();
  }

  Future<void> fetchUserOrders() async {
    try {
      final List<Map<String, dynamic>> fetchedOrders = await dbHelper.getOrdersByEmail(widget.userEmail);
      setState(() {
        userOrders = fetchedOrders;
      });
    } catch (e) {
      print("Error fetching user orders: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch orders. Please try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'My Orders',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor:  Color(0xFF2C7D32),
      ),
      body: userOrders.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: userOrders.length,
        itemBuilder: (context, index) {
          final order = userOrders[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ExpansionTile(
              title: Text(order['customer_name'], style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(
                'Status: ${order['status']}',
                style: TextStyle(color: _getStatusColor(order['status'])),
              ),
              children: [
                ListTile(title: Text('Address: ${order['customer_address']}')),
                ListTile(title: Text('Email: ${order['customer_email']}')),
                ListTile(title: Text('Phone: ${order['customer_phone']}')),
                ListTile(title: Text('Total: Rs ${order['total_amount']}')),
                // Add logic to fetch products associated with the order
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: dbHelper.getOrderItems(order['order_id']),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator();
                    } else if (snapshot.hasError) {
                      return Text("Error loading items");
                    } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return Text("No items in this order");
                    } else {
                      return Column(
                        children: snapshot.data!
                            .map((item) => ListTile(
                          subtitle: Text("Quantity: ${item['quantity']}"),
                        ))
                            .toList(),
                      );
                    }
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case "Delivered":
        return Colors.green;
      case "Shipped":
        return Colors.blue;
      case "Placed":
        return Colors.orange;
      default:
        return Colors.black;
    }
  }
}
