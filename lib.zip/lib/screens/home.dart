import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smartp/screens/AuthScreen.dart';
import 'package:smartp/screens/about_screen.dart';
import 'package:smartp/screens/health.dart';
import 'package:smartp/screens/help_screen.dart';
import 'package:smartp/screens/selection.dart';
import 'package:smartp/screens/shop.dart';
import 'package:smartp/screens/themenotifier.dart';
import 'package:smartp/screens/watering.dart';
import 'package:url_launcher/url_launcher.dart';

class Home extends StatefulWidget {
  final String username;

  const Home({Key? key, required this.username}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _currentIndex = 0;
  final List<String>  _images = ['assets/h2.png', 'assets/h3.png', 'assets/h2.png'];

  Widget _buildDashboardItem(String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      color: Colors.green.shade50,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(33)),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 49, color: color),
              SizedBox(height: 5),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _contactExpert() async {
    final String phoneNumber = '03374663009';
    final String whatsappUrl = 'https://wa.me/$phoneNumber';
    if (await canLaunch(whatsappUrl)) {
      await launch(whatsappUrl);
    } else {
      throw 'Could not launch $whatsappUrl';
    }
  }

  // Add a function to handle the bell icon tap event (e.g., show notifications or something)
  void _handleBellTap() {
    print("Bell icon tapped");
    // Implement the desired functionality here (e.g., navigate to a notifications screen or show a dialog)
  }

  @override
  Widget build(BuildContext context) {
    final themeNotifier = Provider.of<ThemeNotifier>(context);
    final isDarkMode = themeNotifier.isDarkMode;

    return Scaffold(
      backgroundColor: isDarkMode ? Colors.grey[900] : Colors.grey[100],
      appBar: AppBar(
        backgroundColor:  Color(0xFF2C7D32),
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.notifications, color: Colors.yellow.shade100),
            onPressed: _handleBellTap, // Handle the bell icon tap
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              height: 250, // Reduced height
              child: PageView.builder(
                itemCount: _images.length,
                onPageChanged: (index) {
                  setState(() => _currentIndex = index);
                },
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.asset(
                        _images[index],
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                _images.length,
                    (index) => Container(
                  width: 8,
                  height: 20,
                  margin: EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _currentIndex == index ? Colors.green : Colors.grey,
                  ),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: GridView.count(
                  crossAxisCount: 2,
                  childAspectRatio: 1,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 12,
                  children: [
                    _buildDashboardItem('Identify Disease', Icons.search, Colors.lime, () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => PlantDiseaseDetector()));
                    }),
                    _buildDashboardItem('Shop Plant Care', Icons.shopping_cart, Colors.orange, () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ShopScreen()));
                    }),
                    _buildDashboardItem('Water Your Plant', Icons.water_drop, Colors.lightBlueAccent.shade700, () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => SmartPlantixHome()));
                    }),
                    _buildDashboardItem('Identify Plant', Icons.eco, Colors.green, () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => HomeScreen()));
                    }),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                  color: Colors.green
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.green.shade100,
                    child: Text(
                      widget.username.isNotEmpty ? widget.username[0].toUpperCase() : '',
                      style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.green),
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    widget.username,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Plant Enthusiast',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: Icon(Icons.home, color: Colors.green),
              title: Text('Home', style: TextStyle(fontWeight: FontWeight.bold)),
              onTap: () => Navigator.pop(context),
            ),
           /* Divider(),
            SwitchListTile(
              title: Text('Dark/Light Mode', style: TextStyle(fontWeight: FontWeight.bold)),
              value: isDarkMode,
              onChanged: (value) => themeNotifier.toggleTheme(),
              secondary: Icon(
                isDarkMode ? Icons.dark_mode : Icons.light_mode,
                color: Colors.orange,
              ),
            ),*/
            Divider(),
            ListTile(
              leading: Icon(Icons.info, color: Colors.orange),
              title: Text('About', style: TextStyle(fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (context) => AboutScreen()));
              },
            ), Divider(),
            ListTile(
              leading: Icon(Icons.help, color: Colors.blue),
              title: Text('Help', style: TextStyle(fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (context) => AboutScreen()));
              },
            ),

            Divider(),
            ListTile(
              leading: Icon(Icons.logout, color: Colors.red),
              title: Text('Log Out', style: TextStyle(fontWeight: FontWeight.bold)),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => AuthScreen()), // Replace with your login screen
                      (Route<dynamic> route) => false, // Remove all routes
                );
              },
            ),
            Expanded(child: SizedBox()),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'App Version 1.0.0',
                style: TextStyle(color: Colors.grey),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
