import 'dart:io';
import 'package:flutter/material.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image/image.dart' as img;

class PlantDiseaseDetector extends StatefulWidget {
  const PlantDiseaseDetector({super.key});

  @override
  State<PlantDiseaseDetector> createState() => _PlantDiseaseDetectorState();
}

class _PlantDiseaseDetectorState extends State<PlantDiseaseDetector> {
  final picker = ImagePicker();
  File? _image;
  String result = "";
  double confidence = 0.0;
  late Interpreter interpreter;
  bool isAnalyzing = false;
  bool isModelLoaded = false;
  bool isPlant = true; // New flag for plant detection


  // List of supported plants and diseases info remains the same as your original code
  final Map<String, Map<String, String>> diseaseInfo = {
    'Apple__Apple_scab': {
      "cause": "Fungal pathogen Venturia inaequalis that overwinters in fallen leaves. Spread by rain splash and wind. Favored by cool, wet conditions in spring.",
      "treatment": """1. Cultural Control:
• Remove and destroy fallen leaves in autumn
• Prune trees to improve air circulation
• Avoid overhead irrigation

2. Chemical Control:
• Apply protective fungicides like captan or myclobutanil in early spring
• Use copper-based fungicides before bud break
• Consider lime sulfur during dormant season

3. Preventive Measures:
• Plant resistant varieties
• Maintain proper tree spacing
• Monitor weather conditions for disease forecasting"""
    },

    'Apple_Black_rot': {
      "cause": "Fungal pathogen Botryosphaeria obtusa that affects tree branches, leaves, and fruits. Enters through wounds and dead tissue. Thrives in warm, humid conditions.",
      "treatment": """1. Sanitation:
• Remove mummified fruits and cankers
• Prune out dead or diseased wood
• Clean up fallen fruit and leaves

2. Chemical Control:
• Apply fungicides like thiophanate-methyl
• Use captan or myclobutanil during growing season
• Time applications with weather forecasts

3. Cultural Practices:
• Maintain tree vigor through proper fertilization
• Ensure good air circulation
• Protect trees from winter injury"""
    },

    'Apple_Cedar_apple_rust': {
      "cause": "Fungal pathogen Gymnosporangium juniperi-virginianae requiring both apple and cedar/juniper hosts to complete its life cycle. Spreads through wind-blown spores in spring.",
      "treatment": """1. Host Management:
• Remove nearby cedar/juniper trees if possible
• Monitor surrounding area for wild hosts
• Create physical barriers between hosts

2. Chemical Control:
• Apply preventive fungicides in early spring
• Use myclobutanil or propiconazole
• Maintain spray schedule through spring

3. Cultural Practices:
• Plant resistant apple varieties
• Improve air circulation
• Time plantings to avoid peak spore release"""
    },

    'Apple_healthy': {
      "cause": "No disease present. Healthy apple plants show vigorous growth, good leaf color, and normal fruit development.",
      "treatment": """1. Maintenance:
• Regular pruning and training
• Balanced fertilization program
• Proper irrigation management

2. Preventive Care:
• Monitor for early signs of problems
• Maintain orchard hygiene
• Follow recommended cultural practices

3. Ongoing Care:
• Regular soil testing
• Proper nutrient management
• Integrated pest management"""
    },

    'Cherry(including_sour)Powdery_mildew': {
      "cause": "Fungal pathogen Podosphaera clandestina. Thrives in humid conditions with moderate temperatures. Doesn't require free water for infection.",
      "treatment": """1. Cultural Control:
• Improve air circulation through pruning
• Reduce humidity around plants
• Avoid excessive nitrogen fertilization

2. Chemical Control:
• Apply sulfur-based fungicides
• Use potassium bicarbonate sprays
• Consider systemic fungicides in severe cases

3. Prevention:
• Plant resistant varieties
• Space trees properly
• Monitor humidity levels"""
    },

    'Corn(maize)Cercospora_leaf_spot Gray_leaf_spot': {
      "cause": "Fungal pathogen Cercospora zeae-maydis. Favored by warm, humid conditions and prolonged leaf wetness. Survives in crop debris.",
      "treatment": """1. Cultural Management:
• Rotate crops for 1-2 years
• Remove crop debris
• Improve field drainage

2. Chemical Control:
• Apply strobilurin fungicides
• Use preventive fungicides at early stages
• Time applications with weather conditions

3. Resistant Varieties:
• Plant tolerant hybrids
• Consider regional disease pressure
• Select appropriate maturity groups"""
    },

    'Corn(maize)Common_rust': {
      "cause": "Fungal pathogen Puccinia sorghi. Spreads through wind-blown spores. Favors cool, moist conditions with heavy dews.",
      "treatment": """1. Chemical Control:
• Apply foliar fungicides
• Use preventive treatments
• Monitor disease progression

2. Cultural Practices:
• Plant early in the season
• Avoid highly susceptible hybrids
• Maintain proper plant spacing

3. Prevention:
• Use resistant hybrids
• Monitor weather conditions
• Scout fields regularly"""
    },

    'Grape_Black_rot': {
      "cause": "Fungal pathogen Guignardia bidwellii. Overwinters in mummified berries and infected canes. Spreads during warm, wet weather.",
      "treatment": """1. Sanitation:
• Remove mummified fruit
• Prune infected canes
• Clean up fallen debris

2. Chemical Control:
• Apply protective fungicides
• Use systemic fungicides during bloom
• Maintain coverage during fruit development

3. Cultural Management:
• Improve air circulation
• Control canopy density
• Time irrigation to reduce leaf wetness"""
    },

    'Grape_Esca(Black_Measles)': {
      "cause": "Complex of fungi including Phaeomoniella chlamydospora and Phaeoacremonium species. Enters through pruning wounds. Long-term trunk disease.",
      "treatment": """1. Prevention:
• Protect pruning wounds
• Use clean pruning tools
• Avoid stress on vines

2. Cultural Practices:
• Remove infected wood
• Maintain vine vigor
• Proper water management

3. Limited Chemical Options:
• No effective cure available
• Focus on prevention
• Consider vine replacement if severe"""
    },

    'Potato_Early_blight': {
      "cause": "Fungal pathogen Alternaria solani. Favored by warm, wet conditions. Spreads through soil splash and wind.",
      "treatment": """1. Cultural Control:
• Practice crop rotation
• Remove infected plant debris
• Maintain proper plant spacing

2. Chemical Control:
• Apply protective fungicides
• Use chlorothalonil or copper-based products
• Start treatment before disease appears

3. Prevention:
• Use certified seed potatoes
• Maintain proper soil fertility
• Avoid overhead irrigation"""
    },

    'Potato_Late_blight': {
      "cause": "Oomycete pathogen Phytophthora infestans. Rapidly spreading in cool, wet conditions. Historical cause of the Irish Potato Famine.",
      "treatment": """1. Chemical Control:
• Apply fungicides preventively
• Use systemic and contact fungicides
• Maintain regular spray schedule

2. Cultural Practices:
• Destroy volunteer plants
• Improve air circulation
• Plant certified seed potatoes

3. Emergency Response:
• Remove infected plants immediately
• Dispose of infected material properly
• Alert neighboring farmers"""
    },

    'Tomato_Bacterial_spot': {
      "cause": "Bacterial pathogens Xanthomonas species. Spread by water splash, tools, and handling. Favored by warm, wet conditions.",
      "treatment": """1. Prevention:
• Use disease-free seeds
• Rotate crops
• Avoid overhead irrigation

2. Chemical Control:
• Apply copper-based bactericides
• Use disease forecasting
• Combine with mancozeb for better control

3. Cultural Management:
• Remove infected plants
• Clean tools and equipment
• Improve air circulation"""
    },

    'Tomato_Late_blight': {
      "cause": "Oomycete pathogen Phytophthora infestans. Highly destructive disease that spreads rapidly in cool, wet weather. Can destroy entire crops quickly.",
      "treatment": """1. Chemical Control:
• Apply protective fungicides
• Use systemic fungicides
• Maintain regular spray schedule

2. Cultural Practices:
• Remove infected plants
• Improve air circulation
• Avoid overhead irrigation

3. Prevention:
• Plant resistant varieties
• Monitor weather conditions
• Space plants properly"""
    },

    'Tomato_Leaf_Mold': {
      "cause": "Fungal pathogen Passalora fulva. Thrives in high humidity conditions. Common in greenhouse production.",
      "treatment": """1. Environmental Control:
• Reduce humidity
• Improve air circulation
• Manage leaf wetness

2. Chemical Control:
• Apply fungicides preventively
• Use chlorothalonil
• Consider copper-based products

3. Cultural Practices:
• Remove infected leaves
• Space plants properly
• Avoid overhead irrigation"""
    },

    'Tomato_Septoria_leaf_spot': {
      "cause": "Fungal pathogen Septoria lycopersici. Spreads through water splash and contaminated tools. Survives on crop debris.",
      "treatment": """1. Cultural Control:
• Remove infected leaves
• Practice crop rotation
• Mulch around plants

2. Chemical Control:
• Apply fungicides early
• Use chlorothalonil or copper
• Maintain protective coverage

3. Prevention:
• Space plants properly
• Avoid overhead watering
• Clean garden tools"""
    },

    'Tomato_Spider_mites Two-spotted_spider_mite': {
      "cause": "Arthropod pest Tetranychus urticae. Thrives in hot, dry conditions. Rapid reproduction cycle leads to quick population growth.",
      "treatment": """1. Biological Control:
• Introduce predatory mites
• Preserve natural enemies
• Use insecticidal soaps

2. Chemical Control:
• Apply selective miticides
• Use neem oil
• Consider abamectin in severe cases

3. Cultural Control:
• Increase humidity
• Regular plant inspection
• Remove heavily infested leaves"""
    },

    'Tomato_Target_Spot': {
      "cause": "Fungal pathogen Corynespora cassiicola. Favored by warm, humid conditions. Affects all above-ground parts of the plant.",
      "treatment": """1. Cultural Control:
• Improve air circulation
• Reduce leaf wetness
• Remove infected tissue

2. Chemical Control:
• Apply fungicides preventively
• Use broad-spectrum fungicides
• Rotate fungicide classes

3. Prevention:
• Plant resistant varieties
• Proper plant spacing
• Avoid overhead irrigation"""
    },

    'Tomato_Tomato_Yellow_Leaf_Curl_Virus': {
      "cause": "Virus transmitted by whiteflies (Bemisia tabaci). Systemic infection that affects entire plant. Cannot be cured once infected.",
      "treatment": """1. Vector Control:
• Control whitefly populations
• Use reflective mulches
• Install insect screens

2. Prevention:
• Plant resistant varieties
• Remove infected plants
• Start with clean transplants

3. Management:
• Monitor for whiteflies
• Use sticky traps
• Apply appropriate insecticides"""
    },

    'Tomato_Tomato_mosaic_virus': {
      "cause": "Viral pathogen that spreads through physical contact, contaminated tools, and handling. Highly stable and can survive in plant debris.",
      "treatment": """1. Prevention:
• Use virus-free seeds
• Clean tools with disinfectant
• Wash hands between handling plants

2. Management:
• Remove infected plants
• Control weed hosts
• Avoid smoking near plants

3. Cultural Practices:
• Rotate crops
• Use resistant varieties
• Maintain good sanitation"""
    },

    'Orange_Haunglongbing(Citrus_greening)': {
      "cause": "Bacterial pathogen Candidatus Liberibacter spread by Asian citrus psyllid. Systemic infection affecting entire tree. No cure available.",
      "treatment": """1. Vector Control:
• Monitor for psyllids
• Apply appropriate insecticides
• Use biological control agents

2. Tree Management:
• Remove infected trees
• Plant clean nursery stock
• Maintain tree nutrition

3. Prevention:
• Regular scouting
• Area-wide management
• Quarantine measures"""
    },

    'Peach__Bacterial_spot': {
      "cause": "Bacterial pathogen Xanthomonas arboricola pv. pruni. Spreads through water splash and wind-blown rain. Favored by warm, wet weather.",
      "treatment": """1. Chemical Control:
• Apply copper-based bactericides
• Time applications with weather
• Use protective sprays

2. Cultural Practices:
• Prune to improve air flow
• Avoid overhead irrigation
• Remove infected tissue

3. Prevention:
• Plant resistant varieties
• Proper tree spacing
• Maintain good sanitation"""
    },

    'Pepper,_bell_Bacterial_spot': {
      "cause": "Bacterial pathogen Xanthomonas campestris pv. vesicatoria. Spreads through seeds, transplants, and water splash.",
      "treatment": """1. Prevention:
• Use disease-free seeds
• Hot water seed treatment
• Crop rotation

2. Chemical Control:
• Apply copper-based products
• Use disease forecasting
• Combine with mancozeb

3. Cultural Management:
• Avoid overhead irrigation
• Space plants properly
• Remove infected plants"""
    },

    'Squash_Powdery_mildew': {
      "cause": "Fungal pathogens including Podosphaera xanthii and Erysiphe cichoracearum. Thrives in warm, dry conditions with high humidity.",
      "treatment": """1. Cultural Control:
• Space plants properly
• Improve air circulation
• Remove infected leaves

2. Chemical Control:
• Apply sulfur-based fungicides
• Use potassium bicarbonate
• Consider neem oil

3. Prevention:
• Plant resistant varieties
• Time plantings
• Monitor humidity levels"""
    },

    'Strawberry_Leaf_scorch': {
      "cause": "Fungal pathogen Diplocarpon earliana. Favored by warm, wet conditions. Spreads through water splash and leaf contact.",
      "treatment": """1. Cultural Control:
• Remove infected leaves
• Improve air circulation
• Avoid overhead irrigation

2. Chemical Control:
• Apply fungicides preventively
• Use captan or myclobutanil
• Maintain protective coverage

3. Prevention:
• Plant resistant varieties
• Proper plant spacing
• Mulch to reduce splash"""
    },

    'Blueberry_healthy': {
      "cause": "No disease present. Healthy blueberry plants exhibit vibrant green foliage, strong growth, and good fruit production.",
      "treatment": """1. Maintenance:
• Regular pruning to promote airflow
• Balanced fertilization and irrigation
• Mulch to conserve moisture and reduce weeds

2. Preventive Care:
• Watch for pest and disease symptoms
• Practice proper sanitation
• Use disease-resistant varieties"""
    },
    'Cherry(including_sour)healthy': {
      "cause": "No disease present. Healthy cherry trees produce lush foliage and good-quality fruit.",
      "treatment": """1. Maintenance:
• Prune for proper air circulation
• Fertilize appropriately for healthy growth
• Water regularly and evenly

2. Preventive Care:
• Keep the orchard clean and free of debris
• Monitor for pests and early signs of disease"""
    },
    'Corn(maize)healthy': {
      "cause": "No disease present. Healthy maize plants show uniform growth, good leaf color, and strong kernels.",
      "treatment": """1. General Care:
• Maintain proper plant spacing for good airflow
• Fertilize according to soil test results
• Control weeds and pests

2. Preventive Measures:
• Regularly monitor for pests and disease signs
• Rotate crops to reduce disease buildup"""
    },
    'Grape_healthy': {
      "cause": "No disease present. Healthy grapevines exhibit vigorous growth with strong shoots, leaves, and clusters of healthy grapes.",
      "treatment": """1. Maintenance:
• Prune vines to remove dead wood
• Provide balanced nutrients
• Keep the soil consistently moist but not waterlogged

2. Preventive Care:
• Monitor for pests and fungal issues
• Space vines properly to allow for airflow"""
    },
    'Peach_healthy': {
      "cause": "No disease present. Healthy peach trees show lush, green foliage and produce high-quality fruits.",
      "treatment": """1. General Maintenance:
• Prune for air circulation and to remove dead or diseased branches
• Use balanced fertilizers
• Water deeply, especially during dry spells

2. Preventive Care:
• Watch for common peach pests like aphids and borers
• Apply fungicides during critical growing stages to prevent fungal issues"""
    },

    'Pepper,_bell_healthy': {
      "cause": "No disease present. Healthy bell pepper plants are vibrant green with strong foliage and fruit production.",
      "treatment": """1. General Care:
• Prune damaged or dead leaves
• Maintain proper spacing for good airflow
• Fertilize with a balanced mix of nutrients

2. Preventive Measures:
• Regularly inspect for signs of pests and diseases
• Practice crop rotation to reduce pest pressure"""
    },
    'Potato_healthy': {
      "cause": "No disease present. Healthy potato plants show strong foliage, minimal yellowing, and healthy tuber development.",
      "treatment": """1. Maintenance:
• Regularly monitor for pests like aphids and beetles
• Fertilize according to soil test results
• Water consistently and deeply

2. Preventive Care:
• Rotate crops to minimize pest buildup
• Apply fungicides if necessary during wet weather periods"""
    },
    'Raspberry_healthy': {
      "cause": "No disease present. Healthy raspberry plants exhibit vigorous growth with strong, green canes and abundant fruit.",
      "treatment": """1. General Care:
• Prune for proper air circulation and to remove dead canes
• Fertilize with a balanced mix
• Ensure proper irrigation, avoiding waterlogging

2. Prevention:
• Monitor regularly for pests like aphids or spider mites
• Space plants to ensure good airflow"""
    },
    'Soybean_healthy': {
      "cause": "No disease present. Healthy soybean plants show uniform growth with strong stems and healthy pods.",
      "treatment": """1. Maintenance:
• Provide sufficient irrigation
• Apply nitrogen fertilizers if necessary
• Weed control to reduce competition

2. Preventive Care:
• Rotate crops with other legumes
• Regularly scout for pests or signs of disease"""
    },
    'Strawberry_healthy': {
      "cause": "No disease present. Healthy strawberry plants exhibit bright green leaves and vibrant red fruit production.",
      "treatment": """1. General Maintenance:
• Ensure proper drainage and avoid waterlogging
• Mulch to keep fruit clean and reduce weeds
• Prune runners to direct energy to fruit production

2. Preventive Care:
• Inspect plants regularly for pests and fungal issues
• Ensure proper air circulation to reduce fungal risk"""
    }
  };

  final List<String> labels = [
    // ... (keep your existing labels list)
    'Apple__Apple_scab', 'Apple_Black_rot', 'Apple_Cedar_apple_rust', 'Apple_healthy', 'Blueberry_healthy',
    'Cherry(including_sour)Powdery_mildew', 'Cherry(including_sour)healthy',
    'Corn(maize)Cercospora_leaf_spot Gray_leaf_spot', 'Corn(maize)Common_rust',
    'Corn_(maize)Northern_Leaf_Blight', 'Corn(maize)healthy', 'Grape_Black_rot', 'Grape_Esca(Black_Measles)',
    'Grape_Leaf_blight(Isariopsis_Leaf_Spot)', 'Grape_healthy', 'Orange_Haunglongbing(Citrus_greening)',
    'Peach__Bacterial_spot', 'Peach_healthy', 'Pepper,_bell_Bacterial_spot', 'Pepper,_bell_healthy',
    'Potato_Early_blight', 'Potato_Late_blight', 'Potato_healthy', 'Raspberry_healthy', 'Soybean_healthy',
    'Squash_Powdery_mildew', 'Strawberry_Leaf_scorch', 'Strawberry_healthy', 'Tomato_Bacterial_spot',
    'Tomato_Early_blight', 'Tomato_Late_blight', 'Tomato_Leaf_Mold', 'Tomato_Septoria_leaf_spot',
    'Tomato_Spider_mites Two-spotted_spider_mite', 'Tomato_Target_Spot', 'Tomato_Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato_Tomato_mosaic_virus', 'Tomato__healthy'
  ];

  @override
  void initState() {
    super.initState();
    _loadModel();
  }

  Future<void> _loadModel() async {
    try {
      interpreter = await Interpreter.fromAsset('assets/model.tflite');
      setState(() {
        isModelLoaded = true;
      });
    } catch (e) {
      print('Error loading model: $e');
      _showErrorDialog('Failed to load disease detection model.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        content: Text(message, style: GoogleFonts.poppins()),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('OK', style: GoogleFonts.poppins(color: Colors.green)),
          ),
        ],
      ),
    );
  }

  Future<void> _processImage(ImageSource source) async {
    if (!isModelLoaded) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please wait for model to load',
              style: GoogleFonts.poppins()),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    try {
      final pickedFile = await picker.pickImage(source: source);
      if (pickedFile != null) {
        setState(() {
          _image = File(pickedFile.path);
          isAnalyzing = true;
          result = "";
          confidence = 0.0;
          isPlant = true;
        });

        // Basic plant detection check (you might want to implement a more sophisticated check)
        bool isProbablyPlant = await _checkIfPlant(_image!);

        if (!isProbablyPlant) {
          setState(() {
            isAnalyzing = false;
            isPlant = false;
            result = "Not a plant image";
          });
          return;
        }

        await _performAnalysis(_image!);
      }
    } catch (e) {
      print('Error picking image: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to process image',
              style: GoogleFonts.poppins()),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<bool> _checkIfPlant(File image) async {
    try {
      // 1. Check basic image properties
      final imageBytes = await image.readAsBytes();
      img.Image? decodedImage = img.decodeImage(imageBytes);
      if (decodedImage == null) return false;

      // 2. Check dominant colors (plants typically have green components)
      int greenPixels = 0;
      int totalPixels = decodedImage.width * decodedImage.height;

      for (int y = 0; y < decodedImage.height; y++) {
        for (int x = 0; x < decodedImage.width; x++) {
          final pixel = decodedImage.getPixel(x, y);
          int r = img.getRed(pixel);
          int g = img.getGreen(pixel);
          int b = img.getBlue(pixel);

          // Check if pixel is predominantly green (typical for plants)
          if (g > r && g > b && g > 100) {
            greenPixels++;
          }
        }
      }

      // Calculate green ratio (adjust threshold as needed)
      double greenRatio = greenPixels / totalPixels;
      if (greenRatio < 0.15) { // Adjust this threshold based on your needs
        return false;
      }

      // 3. Run model prediction with stricter confidence threshold
      var preprocessedImage = await _preprocessImage(image);
      var output = List.filled(1 * labels.length, 0.0).reshape([1, labels.length]);
      interpreter.run(preprocessedImage, output);

      List<double> outputList = output[0].cast<double>();
      double maxScore = outputList.reduce((a, b) => a > b ? a : b);

      // Stricter confidence threshold
      if (maxScore < 0.5) { // Increased from 0.3 to 0.6
        return false;
      }

      // 4. Additional size check
      if (decodedImage.width < 100 || decodedImage.height < 100) {
        return false;
      }

      return true;
    } catch (e) {
      print('Error in plant detection: $e');
      return false;
    }
  }

// Update the _buildNotPlantCard widget to be more informative
  Widget _buildNotPlantCard() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(Icons.error_outline, size: 48, color: Colors.orange),
            const SizedBox(height: 16),
            Text(
              'Invalid Image Detected',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.orange,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'The image does not appear to be a plant leaf. Please ensure:\n\n'
                  '• The image shows a clear view of plant leaves\n'
                  '• The leaf is well-lit and in focus\n'
                  '• The image is not of gloves, tools, or other gardening equipment\n'
                  '• The leaf takes up a significant portion of the image',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[600],
                height: 1.5,
              ),
              textAlign: TextAlign.left,
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => _clearImage(),
              icon: const Icon(Icons.refresh),
              label: Text('Try Another Image',
                  style: GoogleFonts.poppins()),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

// Add this method to clear the current image
  void _clearImage() {
    setState(() {
      _image = null;
      result = "";
      confidence = 0.0;
      isPlant = true;
    });
  }

  Future<void> _performAnalysis(File image) async {
    try {
      var preprocessedImage = await _preprocessImage(image);
      var output = List.filled(1 * labels.length, 0.0).reshape([1, labels.length]);

      interpreter.run(preprocessedImage, output);

      List<double> outputList = output[0].cast<double>();
      double maxScore = outputList.reduce((a, b) => a > b ? a : b);
      int predictedIndex = outputList.indexWhere((element) => element == maxScore);

      setState(() {
        result = labels[predictedIndex];
        confidence = maxScore * 100;
        isAnalyzing = false;
      });
    } catch (e) {
      setState(() {
        isAnalyzing = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error analyzing image',
              style: GoogleFonts.poppins()),
          backgroundColor: Colors.red,
        ),
      );
    }
  }


  Future<List<List<List<List<double>>>>> _preprocessImage(File image) async {
    final imageBytes = await image.readAsBytes();
    img.Image? imageInput = img.decodeImage(imageBytes);

    if (imageInput == null) {
      throw Exception('Failed to decode image');
    }

    img.Image resizedImg = img.copyResize(imageInput, width: 224, height: 224);

    List<List<List<double>>> image3D = List.generate(
      224,
          (y) => List.generate(
        224,
            (x) {
          final pixel = resizedImg.getPixel(x, y);
          return [
            img.getRed(pixel) / 255.0,
            img.getGreen(pixel) / 255.0,
            img.getBlue(pixel) / 255.0
          ];
        },
      ),
    );

    return [image3D];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              expandedHeight: 200.0,
              floating: false,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                title: Text(
                  'Plant Disease Detection',
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/background.webp', // Make sure to add this image
                      fit: BoxFit.cover,
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.7),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildImageSection(),
                    const SizedBox(height: 24),
                    _buildActionButtons(),
                    if (isAnalyzing) ...[
                      const SizedBox(height: 32),
                      Center(
                        child: Column(
                          children: [
                            const CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                            ),
                            const SizedBox(height: 16),
                            Text('Analyzing image...',
                                style: GoogleFonts.poppins()),
                          ],
                        ),
                      ),
                    ] else if (!isPlant && result.isNotEmpty) ...[
                      const SizedBox(height: 32),
                      _buildNotPlantCard(),
                    ] else if (result.isNotEmpty) ...[
                      const SizedBox(height: 32),
                      _buildResultCard(),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImageSection() {
    return Container(
      height: 300,
      decoration: BoxDecoration(
        color: Colors.yellow.shade50,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: _image == null
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add_photo_alternate,
                size: 64, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(
              'Select or take a photo of a plant',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      )
          : ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.file(
          _image!,
          fit: BoxFit.cover,
          width: double.infinity,
        ),
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton.icon(
          onPressed: () => _processImage(ImageSource.camera),
          icon: const Icon(Icons.camera_alt),
          label: const Text('Camera'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 12,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
        ),
        ElevatedButton.icon(
          onPressed: () => _processImage(ImageSource.gallery),
          icon: const Icon(Icons.photo_library),
          label: const Text('Gallery'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 12,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildResultCard() {
    String diseaseName = result.replaceAll('_', ' ').replaceAll('__', ': ');
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Analysis Results',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green[800],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Detected Condition:',
              style: GoogleFonts.poppins(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              diseaseName,
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 24),
            _buildConfidenceIndicator(),
            const Divider(height: 32),
            _buildEnhancedDiseaseInfo(),
          ],
        ),
      ),
    );
  }

  Widget _buildEnhancedDiseaseInfo() {
    final info = diseaseInfo[result];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Disease Information',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.green[800],
          ),
        ),
        const SizedBox(height: 16),
        if (info != null) ...[
          if (info['cause'] != null)
            _buildInfoItem('Cause', info['cause']!),
          const SizedBox(height: 16),
          if (info['treatment'] != null)
            _buildInfoItem('Treatment', info['treatment']!),
        ] else
          const Text('No detailed information available for this condition'),
      ],
    );
  }

  Widget _buildInfoItem(String title, String content) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                title == 'Cause' ? Icons.info_outline : Icons.medical_services_outlined,
                color: Colors.green[700],
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.green[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            content,
            style: GoogleFonts.poppins(
              fontSize: 14,
              height: 1.5,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConfidenceIndicator() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Confidence Level',
          style: TextStyle(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Text(
              '${confidence.toStringAsFixed(1)}%',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: confidence > 70
                    ? Colors.green
                    : confidence > 50
                    ? Colors.orange
                    : Colors.red,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: confidence / 100,
                  minHeight: 8,
                  backgroundColor: Colors.grey[200],
                  valueColor: AlwaysStoppedAnimation<Color>(
                    confidence > 70
                        ? Colors.green
                        : confidence > 50
                        ? Colors.orange
                        : Colors.red,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDiseaseInfo() {
    final info = diseaseInfo[result];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Disease Information',
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.green[800],
          ),
        ),
        const SizedBox(height: 16),
        if (info != null) ...[

          if (info['treatment'] != null)
            _buildInfoItem('Treatment', info['treatment']!),
        ] else
          const Text('No detailed information available for this condition'),
      ],
    );
  }


  @override
  void dispose() {
    interpreter.close();
    super.dispose();
  }
}