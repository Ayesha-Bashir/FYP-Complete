
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import 'package:google_fonts/google_fonts.dart';

class SmartPlantixHome extends StatefulWidget {
  const SmartPlantixHome({Key? key}) : super(key: key);

  @override
  State<SmartPlantixHome> createState() => _SmartPlantixHomeState();
}

class _SmartPlantixHomeState extends State<SmartPlantixHome> {
  late WebSocketChannel channel;
  bool isConnected = false;
  double moisturePercentage = 0;
  double temperature = 0;
  double humidity = 0;
  bool isPumpOn = false;
  bool isAutoMode = true;
  String ipAddress = '192.168.43.148';

  @override
  void initState() {
    super.initState();
    connectWebSocket();
  }



  void connectWebSocket() {
    try {
      channel = WebSocketChannel.connect(
        Uri.parse('ws://$ipAddress:81/ws'),
      );
      setState(() {
        isConnected = true;
      });

      channel.stream.listen(
            (message) {
          final data = jsonDecode(message);
          setState(() {
            moisturePercentage = data['moisture'].toDouble();
            temperature = data['temperature'].toDouble();
            humidity = data['humidity'].toDouble();
            isPumpOn = data['pump'] == 1;
            isAutoMode = data['mode'] == 'A';
          });
        },
        onError: (error) {
          setState(() {
            isConnected = false;
          });
        },
        onDone: () {
          setState(() {
            isConnected = false;
          });
          // Try to reconnect after a delay
          Future.delayed(const Duration(seconds: 5), connectWebSocket);
        },
      );
    } catch (e) {
      setState(() {
        isConnected = false;
      });
      // Try to reconnect after a delay
      Future.delayed(const Duration(seconds: 5), connectWebSocket);
    }
  }

  void sendCommand(String command, dynamic value) {
    if (isConnected) {
      final message = jsonEncode({
        'command': command,
        'value': value,
      });
      channel.sink.add(message);
    }
  }

  @override
  void dispose() {
    channel.sink.close();
    super.dispose();
  }


  // ... [Keep all your existing WebSocket and control methods exactly the same]

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          '\nWater Your Plant Here...',
          style: GoogleFonts.poppins(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        actions: [
          Container(
            padding: const EdgeInsets.all(10),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              decoration: BoxDecoration(
                color: isConnected ? Colors.green[100] : Colors.red[100],
                borderRadius: BorderRadius.circular(20),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(
                children: [
                  Icon(
                    isConnected ? Icons.wifi : Icons.wifi_off,
                    size: 16,
                    color: isConnected ? Colors.green[800] : Colors.red[800],
                  ),
                  const SizedBox(width: 6),
                  /*Text(
                    isConnected ? 'Connected' : 'Offline',
                    style: TextStyle(
                      color: isConnected ? Colors.green[800] : Colors.red[800],
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ), */
                ],
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Main Moisture Gauge Card
            Container(
              margin: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                //  Padding(
                 //   padding: const EdgeInsets.all(16.0),
                     Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                        SizedBox(height: 5),
                        Text(
                          '\n',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.blue[900],
                          ),
                        ),
                        Icon(Icons.water_drop, color: Colors.blue[700]),
                        const SizedBox(width: 5),
                        Text(
                          'Soil Moisture Level',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.blue[900],
                          ),
                        ),
                      ],
                    ),
              //    ),
                  SizedBox(
                    height: 320,
                    child: SfRadialGauge(
                      enableLoadingAnimation: true,
                      animationDuration: 2000,
                      axes: <RadialAxis>[
                        RadialAxis(
                          minimum: 0,
                          maximum: 100,
                          startAngle: 150,
                          endAngle: 30,
                          radiusFactor: 0.8,
                          showLabels: true,
                          showTicks: true,
                          axisLineStyle: const AxisLineStyle(
                            thickness: 0.2,
                            thicknessUnit: GaugeSizeUnit.factor,
                            cornerStyle: CornerStyle.bothCurve,
                          ),
                          pointers: <GaugePointer>[
                            RangePointer(
                              value: moisturePercentage,
                              width: 0.2,
                              sizeUnit: GaugeSizeUnit.factor,
                              cornerStyle: CornerStyle.bothCurve,
                              gradient: SweepGradient(
                                colors: [Colors.blue[300]!, Colors.blue[700]!],
                                stops: const [0.0, 1.0],
                              ),
                              animationType: AnimationType.ease,
                              enableAnimation: true,
                              animationDuration: 1000,
                            ),
                            MarkerPointer(
                              value: moisturePercentage,
                              markerType: MarkerType.circle,
                              color: Colors.blue[900],
                              markerHeight: 15,
                              markerWidth: 15,
                            ),
                          ],
                          annotations: <GaugeAnnotation>[
                            GaugeAnnotation(
                              widget: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    '  ${moisturePercentage.toStringAsFixed(1)}%',
                                    style: GoogleFonts.poppins(
                                      fontSize: 46,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.blue[900],
                                    ),
                                  ),
                                  Text(
                                    'Moisture',
                                    style: GoogleFonts.poppins(
                                      fontSize: 16,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                              angle: 90,
                              positionFactor: 0.5,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Environment Stats Cards
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      'Temperature',
                      '${temperature.toStringAsFixed(1)}°C',
                      Icons.thermostat,
                      Colors.orange[700]!,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _buildStatCard(
                      'Humidity',
                      '${humidity.toStringAsFixed(1)}%',
                      Icons.water_drop_outlined,
                      Colors.blue[700]!,
                    ),
                  ),
                ],
              ),
            ),

            // Control Buttons
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildControlButton(
                    title: isPumpOn ? 'Pump Active' : 'Pump Inactive',
                    subtitle: 'Tap to toggle pump state On/Off',
                    icon: isPumpOn ? Icons.power : Icons.power_off,
                    isActive: isPumpOn,
                    onTap: () {
                      if (!isAutoMode) {
                        sendCommand('pump', isPumpOn ? 0 : 1);
                      }
                    },
                    disabled: isAutoMode,
                  ),
                  const SizedBox(height: 16),
                  _buildControlButton(
                    title: isAutoMode ? 'Automatic Mode' : 'Manual Mode',
                    subtitle: 'Tap to change control mode [Auto/Manual]',
                    icon: isAutoMode ? Icons.auto_mode : Icons.pan_tool,
                    isActive: isAutoMode,
                    onTap: () {
                      sendCommand('mode', isAutoMode ? 'M' : 'A');
                    },
                    disabled: false,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.shade100,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 32),
          const SizedBox(height: 8),
          Text(
            title,
            style: GoogleFonts.poppins(
              fontSize: 14,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
    required bool disabled,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.lightGreen.shade50,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isActive ? Colors.blue[50] : Colors.grey[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    icon,
                    color: isActive ? Colors.blue[700] : Colors.grey[600],
                    size: 24,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: disabled ? Colors.grey[500] : Colors.black87,
                        ),
                      ),
                      Text(
                        subtitle,
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: isActive,
                  onChanged: disabled ? null : (value) => onTap(),
                  activeColor: Colors.blue[700],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}