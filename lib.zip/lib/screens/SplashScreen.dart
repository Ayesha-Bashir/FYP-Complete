import 'package:flutter/material.dart';
import 'package:smartp/screens/AuthScreen.dart';  // Import the login screen file
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:lottie/lottie.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splash: Column(
        mainAxisAlignment: MainAxisAlignment.center,  // Center everything vertically
        children: [
          LottieBuilder.asset(
         ///  "assets/Lottie/Animation - 1727520794651.json",
          /// "assets/Lottie/Animation - 1727520739354.json",
            "assets/Lottie/Animation - 1727519553944.json",

          ),
          const SizedBox(height: 20), // Space between animation and text
          const Text(
            'Initializing...',  // Cool joining text
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.green,  // Custom text color
              letterSpacing: 2.0,  // Add some spacing to make the text look cool
            ),
          ),
        ],
      ),
      nextScreen: AuthScreen(),
      splashIconSize: 500,
      duration: 10000,  // Duration in milliseconds (10,000 ms = 10 seconds)
      backgroundColor: Colors.white,  // Simplified color definition
    );
  }
}
