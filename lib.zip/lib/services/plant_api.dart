
// lib/services/plant_api.dart
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';

class PlantApiService {
  static const String apiKey = '2b10QpqjHWU6srav8tl6dQwO'; // Get from https://my.plantnet.org/
  static const String baseUrl = 'https://my-api.plantnet.org/v2/identify/all';

  Future<Map<String, dynamic>> identifyPlant(File imageFile) async {
    var uri = Uri.parse('$baseUrl?api-key=$apiKey');

    var request = http.MultipartRequest('POST', uri);
    var image = await http.MultipartFile.fromPath('images', imageFile.path);
    request.files.add(image);

    try {
      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      return json.decode(responseData);
    } catch (e) {
      throw Exception('Failed to identify plant: $e');
    }
  }
}
