import 'package:flutter/material.dart';
import 'package:smartp/Adminside/adminside.dart';
import 'package:smartp/homepage.dart';
import 'package:smartp/screens/SplashScreen.dart';

import 'package:provider/provider.dart';
import 'package:smartp/screens/SplashScreen.dart';
import 'package:smartp/screens/home.dart';
import 'package:smartp/screens/navbar.dart';
import 'package:smartp/screens/shop.dart';
import 'package:smartp/screens/themenotifier.dart';

import 'data/local/db_helper.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    DBHelper db= DBHelper.instance;

    final themeNotifier = Provider.of<ThemeNotifier>(context);

    return MaterialApp(
      title: 'My Planting App ',
      theme: ThemeData.light(), // Light theme
      darkTheme: ThemeData.dark(), // Dark theme
      themeMode: themeNotifier.currentTheme, // Use the themeNotifier to control the theme
      debugShowCheckedModeBanner: false,
        home:SplashScreen(),
      //
    );
  }
}
