import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:smartp/data/local/db_helper.dart';
import 'dart:io';

class AddProductModal extends StatefulWidget {
  final Map<String, dynamic>? product;
  final Function onProductAdded;

  const AddProductModal({Key? key, this.product, required this.onProductAdded}) : super(key: key);

  @override
  _AddProductModalState createState() => _AddProductModalState();
}

class _AddProductModalState extends State<AddProductModal> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  File? _image;
  final picker = ImagePicker();
  DBHelper dbHelper = DBHelper.instance;

  String defaultAssetImage = 'assets/medical-report.png'; // Default asset image path

  @override
  void initState() {
    super.initState();
    if (widget.product != null) {
      _nameController.text = widget.product!['name'];
      _descController.text = widget.product!['description'];
      _priceController.text = widget.product!['price'].toString();
      _quantityController.text = widget.product!['quantity'].toString();
      _image = File(widget.product!['imageUrl']);
    }
  }

  Future<void> _pickImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _submitForm() async {
    final String name = _nameController.text;
    final String description = _descController.text;
    final double? price = double.tryParse(_priceController.text);
    final int? quantity = int.tryParse(_quantityController.text);

    // Validation logic
    if (name.isEmpty || description.isEmpty || price == null || price <= 0 || quantity == null || quantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please complete all fields with valid values')));
      return;
    }

    final String imageUrl = _image?.path ?? defaultAssetImage;

    if (widget.product == null) {
      // Add new product
      await dbHelper.addProduct(
        name: name,
        imageUrl: imageUrl,
        price: price,
        description: description,
        quantity: quantity,
      );
    } else {
      // Update existing product
      await dbHelper.updateProduct(
        id: widget.product!['p_id'],
        name: name,
        imageUrl: imageUrl,
        price: price,
        description: description,
        quantity: quantity,
      );
    }

    widget.onProductAdded();
    Navigator.of(context).pop();
  }


  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.product == null ? 'Add Product' : 'Edit Product'),
      content: SingleChildScrollView(
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Product Name'),
            ),
            TextField(
              controller: _descController,
              decoration: InputDecoration(labelText: 'Product Description'),
            ),
            TextField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _quantityController,
              decoration: InputDecoration(labelText: 'Quantity'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16),
            // Conditional rendering based on whether an image was selected
            _image == null
                ? Image.asset(
              defaultAssetImage, // Use asset image for default
              height: 150,
              fit: BoxFit.cover,
            )
                : Image.file(
              _image!, // Use selected image file if present
              height: 200,
              fit: BoxFit.cover,
            ),
            ElevatedButton(
              onPressed: _pickImage,
              child: Text('Select Image'),
            ),
          ],
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _submitForm,  // Correct submission handling
          child: Text('Submit'),
        ),
      ],
    );
  }
}