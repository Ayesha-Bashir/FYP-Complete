import 'package:flutter/material.dart';
import 'package:smartp/Adminside/productform.dart';
import 'package:smartp/data/local/db_helper.dart';
import 'dart:io';

class ProductPage extends StatefulWidget {
  @override
  _ProductPageState createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  List<Map<String, dynamic>> products = [];
  final DBHelper dbHelper = DBHelper.instance;

  @override
  void initState() {
    super.initState();
    fetchProductsFromDatabase();
  }

  // Fetch products from the database
  Future<void> fetchProductsFromDatabase() async {
    try {
      final List<Map<String, dynamic>> productData = await dbHelper.getAllProducts();
      setState(() {
        products = productData;
      });
    } catch (e) {
      print("Error fetching products: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch products. Please try again.')),
      );
    }
  }

  // Delete a product from the database
  void deleteProduct(int productId) async {
    try {
      await dbHelper.deleteProduct(id: productId);
      fetchProductsFromDatabase(); // Refresh the product list after deletion
    } catch (e) {
      print("Error deleting product: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to delete product. Please try again.')),
      );
    }
  }

  // Show modal to add/edit a product
  void _showAddProModal(BuildContext context, [Map<String, dynamic>? product]) {
    showDialog(
      context: context,
      builder: (_) => AddProductModal(
        product: product,
        onProductAdded: fetchProductsFromDatabase, // Refresh products after adding
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text('My Products', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Product List',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                ElevatedButton.icon(
                  onPressed: () => _showAddProModal(context),
                  icon: Icon(Icons.add),
                  label: Text("Add New"),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white, backgroundColor: Colors.green,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: products.isEmpty
                ? Center(child: CircularProgressIndicator()) // Loading state
                : ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                final product = products[index];
                return Card(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: ListTile(
                    leading: product['imageUrl'] != null
                        ? Image.file(File(product['imageUrl']), width: 50, height: 50, fit: BoxFit.cover)
                        : Image.asset(''),
                    title: Text(product['name'], style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(product['description']),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('\Rs ${product['price']}', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                            Text('Qty: ${product['quantity']}', style: TextStyle(color: Colors.grey)),
                          ],
                        ),
                        SizedBox(width: 16),
                        IconButton(
                          icon: Icon(Icons.edit, color: Colors.blue),
                          onPressed: () => _showAddProModal(context, product), // Pass product for editing
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => deleteProduct(product['p_id']),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
