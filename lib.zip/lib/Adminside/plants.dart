import 'package:flutter/material.dart';

class PlantIdentifierPage extends StatefulWidget {
  @override
  _PlantIdentifierPageState createState() => _PlantIdentifierPageState();
}

class _PlantIdentifierPageState extends State<PlantIdentifierPage> {
  List<Map<String, dynamic>> plants = [
    {
      "plantImage": 'assets/IMG1.png',
      "plantName": "Fern",
      "description": "A graceful plant known for its feathery leaves and lush green appearance.",
    },
    {
      "plantImage": 'assets/IMG2.png',
      "plantName": "Cactus",
      "description": "A hardy plant that thrives in dry environments, often with spines instead of leaves.",
    },
    {
      "plantImage": 'assets/IMG2.png',
      "plantName": "Bamboo",
      "description": "A fast-growing grass known for its tall, woody stems and versatility.",
    },
    {
      "plantImage": 'assets/IMG1.png',
      "plantName": "Sunflower",
      "description": "A bright yellow flower known for turning to face the sun.",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Plant Identifier', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
      ),
      body: GridView.builder(
        padding: EdgeInsets.all(16),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 0.75,
        ),
        itemCount: plants.length,
        itemBuilder: (context, index) {
          final plant = plants[index];
          return Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
                    child: Image.asset(
                      plant['plantImage'],
                      fit: BoxFit.cover,
                      width: double.infinity,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        plant['plantName'],
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      SizedBox(height: 4),
                      Text(
                        plant['description'],
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}