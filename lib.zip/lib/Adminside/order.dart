import 'package:flutter/material.dart';
import 'package:smartp/data/local/db_helper.dart';

class OrderPage extends StatefulWidget {
  @override
  _OrderPageState createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  List<Map<String, dynamic>> orders = [];
  Map<int, List<Map<String, dynamic>>> orderItems = {};
  final DBHelper dbHelper = DBHelper.instance;

  @override
  void initState() {
    super.initState();
    fetchOrders();
  }

  Future<void> fetchOrders() async {
    try {
      final List<Map<String, dynamic>> fetchedOrders = await dbHelper.getAllOrders();
      final Map<int, List<Map<String, dynamic>>> fetchedOrderItems = {};

      for (var order in fetchedOrders) {
        final int orderId = order['order_id'];
        final List<Map<String, dynamic>> items = await dbHelper.getOrderItems(orderId);
        fetchedOrderItems[orderId] = items;
      }

      setState(() {
        orders = fetchedOrders;
        orderItems = fetchedOrderItems;
      });
    } catch (e) {
      print("Error fetching orders: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to fetch orders. Please try again.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Orders', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
      ),
      body: orders.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) {
          final order = orders[index];
          final items = orderItems[order['order_id']] ?? [];

          return Card(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ExpansionTile(
              title: Text(order['customer_name'], style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(
                'Status: ${order['status']}',
                style: TextStyle(color: _getStatusColor(order['status'])),
              ),
              children: [
                ListTile(title: Text('Address: ${order['customer_address']}')),
                ListTile(title: Text('Email: ${order['customer_email']}')),
                ListTile(title: Text('Phone: ${order['customer_phone']}')),
                ListTile(title: Text('Total: Rs ${order['total_amount']}')),
                Divider(),
                Text('Products', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                ...items.map((item) => ListTile(
                  title: Text(item['product_name']),
                  subtitle: Text('Quantity: ${item['quantity']}'),
                )),
                ButtonBar(
                  alignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () => _updateStatus(order['order_id'], order['status']),
                      child: Text('Update Status'),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.lightBlueAccent),
                    ),
                    ElevatedButton(
                      onPressed: () => _deleteOrder(order['order_id']),
                      child: Text('Delete Order'),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.amberAccent),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case "Delivered":
        return Colors.green;
      case "Shipped":
        return Colors.blue;
      case "Placed":
        return Colors.orange;
      default:
        return Colors.black;
    }
  }

  void _updateStatus(int orderId, String currentStatus) {
    showDialog(
      context: context,
      builder: (context) {
        String newStatus = currentStatus;
        return AlertDialog(
          title: Text('Update Order Status'),
          content: DropdownButton<String>(
            value: newStatus,
            items: <String>['Placed', 'Shipped', 'Delivered'].map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            onChanged: (String? newValue) async {
              if (newValue != null) {
                // Update the order in the database
                final updated = await dbHelper.updateOrder(
                  orderId: orderId,
                  customerName: orders.firstWhere((order) => order['order_id'] == orderId)['customer_name'],
                  customerPhone: orders.firstWhere((order) => order['order_id'] == orderId)['customer_phone'],
                  customerEmail: orders.firstWhere((order) => order['order_id'] == orderId)['customer_email'],
                  customerAddress: orders.firstWhere((order) => order['order_id'] == orderId)['customer_address'],
                  totalAmount: orders.firstWhere((order) => order['order_id'] == orderId)['total_amount'],
                  status: newValue,
                  payOnDelivery: orders.firstWhere((order) => order['order_id'] == orderId)['pay_on_delivery'] == 1,
                );

                if (updated > 0) {
                  await fetchOrders(); // Refresh the orders list after updating
                  Navigator.of(context).pop();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to update order status')));
                }
              }
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  void _deleteOrder(int orderId) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Delete Order'),
          content: Text('Are you sure you want to delete this order?'),
          actions: [
            TextButton(
              onPressed: () async {
                final deleted = await dbHelper.deleteOrder(orderId);
                if (deleted > 0) {
                  await fetchOrders(); // Refresh the orders list after deletion
                  Navigator.of(context).pop();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to delete order')));
                }
              },
              child: Text('Yes'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('No'),
            ),
          ],
        );
      },
    );
  }
}
