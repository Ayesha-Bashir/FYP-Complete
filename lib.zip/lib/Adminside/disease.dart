import 'package:flutter/material.dart';

class DiseasePage extends StatefulWidget {
  @override
  _DiseasePageState createState() => _DiseasePageState();
}

class _DiseasePageState extends State<DiseasePage> {
  List<Map<String, dynamic>> diseases = [
    {
      "leafImage": 'assets/kit1.jpeg',
      "disease": "Blight",
      "description": "A fungal disease causing dark, sunken spots on leaves and stems.",
    },
    {
      "leafImage": 'assets/kit1.jpeg',
      "disease": "Late Blight",
      "description": "Caused by the pathogen Phytophthora infestans, it leads to dark lesions on leaves.",
    },
    {
      "leafImage": 'assets/kit1.jpeg',
      "disease": "Powdery Mildew",
      "description": "A fungal disease characterized by white powdery spots on leaves.",
    },
    {
      "leafImage": 'assets/kit1.jpeg',
      "disease": "Cucumber Mosaic Virus",
      "description": "A viral disease causing yellow mottling and stunted growth.",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Plant Diseases', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
      ),
      body: ListView.builder(
        itemCount: diseases.length,
        itemBuilder: (context, index) {
          final disease = diseases[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              leading: Image.asset(
                disease['leafImage'],
                width: 50,
                height: 50,
                fit: BoxFit.cover,
              ),
              title: Text(disease['disease'], style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(disease['description']),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text(disease['disease']),
                      content: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.asset(disease['leafImage']),
                            SizedBox(height: 16),
                            Text(disease['description']),
                          ],
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: Text('Close'),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          );
        },
      ),
    );
  }
}