import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smartp/data/local/db_helper.dart';
import 'userform.dart';

class UsersProvider extends ChangeNotifier {
  DBHelper dbHelper = DBHelper.instance;
  List<Map<String, dynamic>> _users = [];

  int get userCount => _users.length; // Add this line to track the number of users


  List<Map<String, dynamic>> get users => _users;

  // Fetch users from the database
  Future<void> fetchUsers() async {
    _users = await dbHelper.getAllUsers();
    notifyListeners();
  }

  // Delete user from the database and refresh the list
  Future<void> deleteUser(String email) async {
    int success = await dbHelper.deleteUser(email: email);  // now the parameter name matches
    if (success==1) {
      await fetchUsers();
    }
  }

  // Update user in the database and refresh the list
  Future<void> updateUser(String name, String newEmail, String currentEmail) async {
    int success = await dbHelper.updateUser(name: name, newEmail: newEmail, currentEmail: currentEmail);
    if (success==1) {
      await fetchUsers();
    }
  }
}

class UserPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => UsersProvider()..fetchUsers(),
      child: UserPageContent(),
    );
  }
}

class UserPageContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Users'),
        backgroundColor: Color(0xFF2C7D32),
      ),
      body: Column(
        children: [
          _buildSearchBar(),
          Expanded(child: _buildUserList()),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: EdgeInsets.all(8.0),
      child: TextField(
        decoration: InputDecoration(
          hintText: 'Search users...',
          prefixIcon: Icon(Icons.search),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.grey[200],
        ),
      ),
    );
  }

  Widget _buildUserList() {
    return Consumer<UsersProvider>(
      builder: (context, usersProvider, child) {
        return ListView.builder(
          itemCount: usersProvider.users.length,
          itemBuilder: (context, index) {
            final user = usersProvider.users[index];
            return Card(
              margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: ListTile(
                leading: CircleAvatar(
                  child: Text(user[DBHelper.COLUMN_Name][0]),
                  backgroundColor: Color(0xFF2C7D32),
                ),
                title: Text(user[DBHelper.COLUMN_Name]),
                subtitle: Text(user[DBHelper.COLUMN_Email]),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [

                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => usersProvider.deleteUser(user[DBHelper.COLUMN_Email]),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showEditUserModal(BuildContext context, String currentName, String currentEmail) {
    TextEditingController nameController = TextEditingController(text: currentName);
    TextEditingController emailController = TextEditingController(text: currentEmail);

    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          title: Text('Edit User'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Name'),
              ),
              TextField(
                controller: emailController,
                decoration: InputDecoration(labelText: 'Email'),
              ),
            ],
          ),
          actions: [
            TextButton(
              child: Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Update'),
              onPressed: () {
                final newName = nameController.text;
                final newEmail = emailController.text;
                if (newName.isNotEmpty && newEmail.isNotEmpty) {
                  // Pass currentEmail to identify which user to update
                  Provider.of<UsersProvider>(context, listen: false).updateUser(newName, newEmail, currentEmail);
                  Navigator.of(context).pop();
                }
              },
            ),
          ],
        );
      },
    );
  }
}
