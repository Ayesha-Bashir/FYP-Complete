import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:smartp/screens/AuthScreen.dart';
import 'user.dart';
import 'product.dart';
import 'order.dart';
import 'disease.dart';
import 'plants.dart';
import 'package:smartp/Adminside/disease.dart';
import 'package:smartp/Adminside/plants.dart';
import 'package:smartp/Adminside/disease.dart' as diseasePage;
import 'package:smartp/Adminside/plants.dart' as plantsPage;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:smartp/data/local/db_helper.dart';
import 'package:google_fonts/google_fonts.dart';

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  DBHelper dbHelper = DBHelper.instance;

  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _orders = [];

  int outOfStockCount = 0;
  int lowStockCount = 0;

  double Orderstotal=0.0;

  int get userCount => _users.length;
  int get productCount => _products.length;
  int get orderCount => _orders.length;

  @override
  void initState() {
    super.initState();
    fetchUsers();
    fetchProducts();
    fetchOrderss();
  }

  // Fetch users from the database
  Future<void> fetchUsers() async {
    List<Map<String, dynamic>> user = await dbHelper.getAllUsers();
    setState(() {
      _users = user;
    });
  }

  Future<void> fetchOrderss() async {
    List<Map<String, dynamic>> od = await dbHelper.getAllOrders();
    setState(() {
      _orders = od;
      Orderstotal = calculateTotalRevenue(_orders);
    });
  }


  double calculateTotalRevenue(List<Map<String, dynamic>> orders) {
    double total = 0.0;

    // Iterate through the list and sum the `total_amount` field
    for (var od in orders) {
      total += (od['total_amount'] ?? 0.0).toDouble(); // Ensure total_amount is treated as a double
    }

    return total;
  }

  // Fetch products and calculate stock levels
  Future<void> fetchProducts() async {
    List<Map<String, dynamic>> productList = await dbHelper.getAllProducts();
    int lowStock = 0;
    int outOfStock = 0;

    // Calculate low stock and out of stock products
    for (var product in productList) {
      int quantity = product['quantity'] ?? 0;
      if (quantity == 0) {
        outOfStock++;
      } else if (quantity > 0 && quantity <= 5) {
        lowStock++;
      }
    }

    setState(() {
      _products = productList;
      outOfStockCount = outOfStock;
      lowStockCount = lowStock;
    });
  }


  Widget _buildWelcomeText() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Welcome Admin!',
          style: GoogleFonts.poppins(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.green.shade800,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Your plant management and identification dashboard is ready to serve.',
          style: GoogleFonts.poppins(
            fontSize: 16,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      drawer: _buildDrawer(context),
      body: _buildBody(),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: Text('', style: TextStyle(color: Colors.white)),
      backgroundColor: Color(0xFF2C7D32),
      elevation: 0,

    );
  }

  Drawer _buildDrawer(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Color(0xFF2C7D32)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  backgroundImage: AssetImage('assets/admin.jpg'),
                  radius: 30,
                ),
                SizedBox(height: 10),
                Text('Ayesha Basir', style: TextStyle(color: Colors.white, fontSize: 18)),
                Text('24767@students.riphah.edu.pk', style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          _buildDrawerItem(context, Icons.dashboard, 'Dashboard', () {}),
          _buildDrawerItem(context, Icons.people, 'Users', () => Navigator.push(context, MaterialPageRoute(builder: (_) => UserPage()))),
          _buildDrawerItem(context, Icons.shopping_cart, 'Products', () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductPage()))),
          _buildDrawerItem(context, Icons.list_alt, 'Orders', () => Navigator.push(context, MaterialPageRoute(builder: (_) => OrderPage()))),
          _buildDrawerItem(context, Icons.local_hospital, 'Diseases', () => Navigator.push(context, MaterialPageRoute(builder: (_) => diseasePage.DiseasePage()))),
        //  _buildDrawerItem(context, Icons.eco, 'Plants', () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlantIdentifierPage()))),
          Divider(),
          _buildDrawerItem(context, Icons.logout, 'Logout', () {
            SharedPreferences.getInstance().then((prefs) {
              prefs.clear(); // Clear all saved user data
            });
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => AuthScreen()), // Replace with your login screen
                  (Route<dynamic> route) => false, // Remove all routes
            );
          }),
        ],
      ),
    );
  }

  ListTile _buildDrawerItem(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: Color(0xFF2C7D32)),
      title: Text(title),
      onTap: onTap,
    );
  }

  Widget _buildBody() {

    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 20),
          _buildWelcomeText(),

          SizedBox(height: 20),
          _buildSummaryWidget(),

          SizedBox(height: 20),
          _buildGridDashboard(),
        ],
      ),
    );
  }

  Widget _buildSummaryWidget() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
           // _buildSummaryItem(Icons.monetization_on, 'Total Revenue', 'Rs ${Orderstotal.toStringAsFixed(1)}'),
            _buildSummaryItem(Icons.shopping_cart, 'Orders', '$orderCount'),
            _buildSummaryItem(Icons.people, 'Customers', '$userCount'),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryItem(IconData icon, String title, String value) {
    return Column(
      children: [
        Icon(icon, size: 35, color: Color(0xFF2C7D32)),
        SizedBox(height: 8),
        Text(title, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
        Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }



  Widget _buildGridDashboard() {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      children: [
        _buildDashboardCard('All Products', '$productCount', Icons.shopping_bag, Colors.blue),
        _buildDashboardCard('Out of Stock', '$outOfStockCount', Icons.inventory, Colors.red),
        _buildDashboardCard('Low Stock', '$lowStockCount', Icons.warning, Colors.orange),
        _buildDashboardCard('Detect Diseases', '9', Icons.trending_up, Colors.green),
      ],
    );
  }

  Widget _buildDashboardCard(String title, String count, IconData icon, Color color) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 30, color: color),
            SizedBox(height: 16),
            Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text(count, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }
}
